"""
JTel Identity Standard (JIS) Client for Raspberry Pi
=====================================================

This client implements the JIS protocol for edge devices:
- Device Identity (DID) management
- FIR/A (Flag → Identify → Revoke/Accept) handshakes
- ContinuityChain maintenance
- Intent verification
- Sense integration

Author: Jasper van de Meent / JTel
License: Proprietary
"""

import asyncio
import json
import hashlib
import uuid
import time
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any, List, Callable
from enum import Enum
import aiohttp
import aiofiles


# =============================================================================
# Configuration
# =============================================================================

class Config:
    """Configuration for the JIS client"""
    
    # Brein backend
    BREIN_URL = "http://192.168.4.76:8081"  # Adjust to your server
    BREIN_WS_URL = "ws://192.168.4.76:9000"
    
    # Device identity storage
    IDENTITY_FILE = Path("/home/pi/.jtel/device_identity.json")
    CHAIN_FILE = Path("/home/pi/.jtel/continuity_chain.json")
    FIRA_FILE = Path("/home/pi/.jtel/fira_relations.json")
    
    # Device info
    DEVICE_NAME = "Home-Pi"
    DEVICE_TYPE = "edge-assistant"
    DEVICE_CAPABILITIES = ["sense", "actuate", "llm", "audio"]
    
    # Timeouts
    VERIFY_TIMEOUT = 5.0
    WS_RECONNECT_DELAY = 5.0


# =============================================================================
# Data Classes
# =============================================================================

class IntentCategory(Enum):
    QUERY = "query"
    COMFORT = "comfort"
    SECURITY = "security"
    COMMUNICATION = "communication"
    EMERGENCY = "emergency"
    SYSTEM = "system"


@dataclass
class DeviceIdentity:
    """The device's own identity"""
    did: str
    private_key: str  # In production: use secure enclave
    created_at: str
    device_name: str
    device_type: str
    capabilities: List[str]
    
    def to_public(self) -> Dict:
        """Return public identity info (no private key)"""
        return {
            "did": self.did,
            "device_name": self.device_name,
            "device_type": self.device_type,
            "capabilities": self.capabilities,
            "created_at": self.created_at
        }


@dataclass
class FIRARelation:
    """A FIR/A relationship with another entity"""
    fir_a_id: str
    remote_did: str
    role: str
    intent_whitelist: List[str]
    created_at: str
    last_interaction: str
    event_count: int
    continuity_hash: str
    status: str  # "active", "suspended", "revoked"


@dataclass
class ChainEvent:
    """An event in the ContinuityChain"""
    event_id: str
    timestamp: str
    event_type: str
    remote_did: Optional[str]
    intent: Optional[str]
    result: str
    data_hash: str
    previous_hash: str
    current_hash: str


@dataclass
class Intent:
    """An incoming intent from another entity"""
    sender_did: str
    category: IntentCategory
    action: str
    params: Dict[str, Any]
    continuity_hash: str
    timestamp: str
    signature: str


@dataclass 
class VerificationResult:
    """Result of verifying an incoming intent"""
    valid: bool
    fir_a: Optional[FIRARelation]
    role: Optional[str]
    reason: Optional[str]


# =============================================================================
# ContinuityChain Manager
# =============================================================================

class ContinuityChain:
    """Manages the device's continuity chain"""
    
    def __init__(self, chain_file: Path):
        self.chain_file = chain_file
        self.events: List[ChainEvent] = []
        self.current_hash: str = self._genesis_hash()
    
    def _genesis_hash(self) -> str:
        """Generate the genesis hash for a new chain"""
        genesis = f"genesis:{Config.DEVICE_NAME}:{datetime.utcnow().isoformat()}"
        return hashlib.sha256(genesis.encode()).hexdigest()[:32]
    
    def _compute_hash(self, event_data: str, previous_hash: str) -> str:
        """Compute hash for a new event"""
        combined = f"{previous_hash}:{event_data}"
        return hashlib.sha256(combined.encode()).hexdigest()[:32]
    
    async def load(self):
        """Load chain from disk"""
        if self.chain_file.exists():
            async with aiofiles.open(self.chain_file, 'r') as f:
                data = json.loads(await f.read())
                self.events = [ChainEvent(**e) for e in data.get("events", [])]
                self.current_hash = data.get("current_hash", self._genesis_hash())
    
    async def save(self):
        """Save chain to disk"""
        self.chain_file.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "events": [asdict(e) for e in self.events[-1000:]],  # Keep last 1000
            "current_hash": self.current_hash
        }
        async with aiofiles.open(self.chain_file, 'w') as f:
            await f.write(json.dumps(data, indent=2))
    
    async def append(
        self,
        event_type: str,
        remote_did: Optional[str] = None,
        intent: Optional[str] = None,
        result: str = "success",
        extra_data: Optional[Dict] = None
    ) -> ChainEvent:
        """Append a new event to the chain"""
        
        event_data = json.dumps({
            "type": event_type,
            "remote_did": remote_did,
            "intent": intent,
            "result": result,
            "extra": extra_data or {},
            "timestamp": datetime.utcnow().isoformat()
        }, sort_keys=True)
        
        data_hash = hashlib.sha256(event_data.encode()).hexdigest()[:16]
        new_hash = self._compute_hash(event_data, self.current_hash)
        
        event = ChainEvent(
            event_id=str(uuid.uuid4()),
            timestamp=datetime.utcnow().isoformat(),
            event_type=event_type,
            remote_did=remote_did,
            intent=intent,
            result=result,
            data_hash=data_hash,
            previous_hash=self.current_hash,
            current_hash=new_hash
        )
        
        self.events.append(event)
        self.current_hash = new_hash
        
        await self.save()
        return event
    
    def get_recent(self, count: int = 10) -> List[ChainEvent]:
        """Get recent events"""
        return self.events[-count:]
    
    def verify_integrity(self) -> bool:
        """Verify the chain integrity"""
        if not self.events:
            return True
        
        for i, event in enumerate(self.events[1:], 1):
            if event.previous_hash != self.events[i-1].current_hash:
                return False
        
        return True


# =============================================================================
# FIR/A Manager
# =============================================================================

class FIRAManager:
    """Manages FIR/A relationships"""
    
    def __init__(self, fira_file: Path):
        self.fira_file = fira_file
        self.relations: Dict[str, FIRARelation] = {}
    
    async def load(self):
        """Load relations from disk"""
        if self.fira_file.exists():
            async with aiofiles.open(self.fira_file, 'r') as f:
                data = json.loads(await f.read())
                for fid, rel in data.items():
                    self.relations[fid] = FIRARelation(**rel)
    
    async def save(self):
        """Save relations to disk"""
        self.fira_file.parent.mkdir(parents=True, exist_ok=True)
        data = {fid: asdict(rel) for fid, rel in self.relations.items()}
        async with aiofiles.open(self.fira_file, 'w') as f:
            await f.write(json.dumps(data, indent=2))
    
    def get_by_did(self, remote_did: str) -> Optional[FIRARelation]:
        """Get relation by remote DID"""
        for rel in self.relations.values():
            if rel.remote_did == remote_did and rel.status == "active":
                return rel
        return None
    
    def get_by_id(self, fir_a_id: str) -> Optional[FIRARelation]:
        """Get relation by FIR/A ID"""
        return self.relations.get(fir_a_id)
    
    async def create(
        self,
        fir_a_id: str,
        remote_did: str,
        role: str,
        intent_whitelist: List[str],
        initial_hash: str
    ) -> FIRARelation:
        """Create a new FIR/A relation"""
        now = datetime.utcnow().isoformat()
        
        relation = FIRARelation(
            fir_a_id=fir_a_id,
            remote_did=remote_did,
            role=role,
            intent_whitelist=intent_whitelist,
            created_at=now,
            last_interaction=now,
            event_count=1,
            continuity_hash=initial_hash,
            status="active"
        )
        
        self.relations[fir_a_id] = relation
        await self.save()
        return relation
    
    async def update_interaction(
        self,
        fir_a_id: str,
        new_hash: str
    ):
        """Update relation after interaction"""
        if fir_a_id in self.relations:
            rel = self.relations[fir_a_id]
            rel.last_interaction = datetime.utcnow().isoformat()
            rel.event_count += 1
            rel.continuity_hash = new_hash
            await self.save()
    
    async def revoke(self, fir_a_id: str, reason: str = "manual"):
        """Revoke a relation"""
        if fir_a_id in self.relations:
            self.relations[fir_a_id].status = "revoked"
            await self.save()
    
    def can_execute(self, relation: FIRARelation, intent_category: str) -> bool:
        """Check if relation allows this intent category"""
        if relation.status != "active":
            return False
        if "*" in relation.intent_whitelist:
            return True
        return intent_category in relation.intent_whitelist


# =============================================================================
# Main JIS Client
# =============================================================================

class JISClient:
    """Main JIS client for Raspberry Pi"""
    
    def __init__(self):
        self.identity: Optional[DeviceIdentity] = None
        self.chain = ContinuityChain(Config.CHAIN_FILE)
        self.fira = FIRAManager(Config.FIRA_FILE)
        
        self.ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self.session: Optional[aiohttp.ClientSession] = None
        
        self.intent_handlers: Dict[str, Callable] = {}
        self.nir_handlers: List[Callable] = []
        
        self._running = False
    
    # -------------------------------------------------------------------------
    # Initialization
    # -------------------------------------------------------------------------
    
    async def initialize(self):
        """Initialize the JIS client"""
        print("[JIS] Initializing...")
        
        # Load or create identity
        await self._load_or_create_identity()
        
        # Load chain and relations
        await self.chain.load()
        await self.fira.load()
        
        # Verify chain integrity
        if not self.chain.verify_integrity():
            print("[JIS] WARNING: Chain integrity check failed!")
        
        # Create HTTP session
        self.session = aiohttp.ClientSession()
        
        # Register with Brein
        await self._register_with_brein()
        
        print(f"[JIS] Initialized. DID: {self.identity.did}")
        print(f"[JIS] Chain events: {len(self.chain.events)}")
        print(f"[JIS] FIR/A relations: {len(self.fira.relations)}")
    
    async def _load_or_create_identity(self):
        """Load existing identity or create new one"""
        if Config.IDENTITY_FILE.exists():
            async with aiofiles.open(Config.IDENTITY_FILE, 'r') as f:
                data = json.loads(await f.read())
                self.identity = DeviceIdentity(**data)
                print(f"[JIS] Loaded existing identity: {self.identity.did}")
        else:
            # Generate new identity
            did = f"did:jtel:device:{uuid.uuid4().hex[:16]}"
            private_key = hashlib.sha256(uuid.uuid4().bytes).hexdigest()
            
            self.identity = DeviceIdentity(
                did=did,
                private_key=private_key,
                created_at=datetime.utcnow().isoformat(),
                device_name=Config.DEVICE_NAME,
                device_type=Config.DEVICE_TYPE,
                capabilities=Config.DEVICE_CAPABILITIES
            )
            
            # Save identity
            Config.IDENTITY_FILE.parent.mkdir(parents=True, exist_ok=True)
            async with aiofiles.open(Config.IDENTITY_FILE, 'w') as f:
                await f.write(json.dumps(asdict(self.identity), indent=2))
            
            print(f"[JIS] Created new identity: {self.identity.did}")
    
    async def _register_with_brein(self):
        """Register this device with the Brein backend"""
        try:
            async with self.session.post(
                f"{Config.BREIN_URL}/device/register",
                json={
                    "did": self.identity.did,
                    "device_info": self.identity.to_public(),
                    "continuity_hash": self.chain.current_hash
                }
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    print(f"[JIS] Registered with Brein: {data}")
                else:
                    print(f"[JIS] Brein registration failed: {resp.status}")
        except Exception as e:
            print(f"[JIS] Could not reach Brein: {e}")
    
    # -------------------------------------------------------------------------
    # WebSocket Connection
    # -------------------------------------------------------------------------
    
    async def connect_websocket(self):
        """Connect to Brein WebSocket for real-time communication"""
        self._running = True
        
        while self._running:
            try:
                print(f"[JIS] Connecting to WebSocket: {Config.BREIN_WS_URL}")
                
                async with self.session.ws_connect(Config.BREIN_WS_URL) as ws:
                    self.ws = ws
                    
                    # Send identity
                    await ws.send_json({
                        "type": "device_connect",
                        "did": self.identity.did,
                        "continuity_hash": self.chain.current_hash
                    })
                    
                    print("[JIS] WebSocket connected")
                    
                    # Listen for messages
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            await self._handle_ws_message(json.loads(msg.data))
                        elif msg.type == aiohttp.WSMsgType.ERROR:
                            print(f"[JIS] WebSocket error: {ws.exception()}")
                            break
                
            except Exception as e:
                print(f"[JIS] WebSocket connection failed: {e}")
            
            if self._running:
                print(f"[JIS] Reconnecting in {Config.WS_RECONNECT_DELAY}s...")
                await asyncio.sleep(Config.WS_RECONNECT_DELAY)
    
    async def _handle_ws_message(self, message: Dict):
        """Handle incoming WebSocket message"""
        msg_type = message.get("type")
        
        if msg_type == "intent":
            await self._handle_intent(message)
        
        elif msg_type == "fira_request":
            await self._handle_fira_request(message)
        
        elif msg_type == "nir":
            await self._handle_nir(message)
        
        elif msg_type == "ping":
            await self.ws.send_json({"type": "pong", "did": self.identity.did})
        
        else:
            print(f"[JIS] Unknown message type: {msg_type}")
    
    # -------------------------------------------------------------------------
    # FIR/A Protocol
    # -------------------------------------------------------------------------
    
    async def _handle_fira_request(self, message: Dict):
        """Handle incoming FIR/A request (someone wants to connect)"""
        remote_did = message.get("remote_did")
        proposed_role = message.get("role")
        intent_whitelist = message.get("intent_whitelist", [])
        
        print(f"[JIS] FIR/A request from {remote_did}, role: {proposed_role}")
        
        # Check if we already have a relation
        existing = self.fira.get_by_did(remote_did)
        if existing:
            print(f"[JIS] Already have FIR/A with {remote_did}")
            await self.ws.send_json({
                "type": "fira_response",
                "status": "exists",
                "fir_a_id": existing.fir_a_id,
                "remote_did": remote_did
            })
            return
        
        # Auto-accept known roles (in production: more sophisticated logic)
        auto_accept_roles = ["owner", "admin", "user", "brein"]
        
        if proposed_role in auto_accept_roles:
            # Accept
            fir_a_id = str(uuid.uuid4())
            initial_hash = hashlib.sha256(
                f"{fir_a_id}:{remote_did}:{self.identity.did}".encode()
            ).hexdigest()[:32]
            
            relation = await self.fira.create(
                fir_a_id=fir_a_id,
                remote_did=remote_did,
                role=proposed_role,
                intent_whitelist=intent_whitelist or ["*"],
                initial_hash=initial_hash
            )
            
            # Log to chain
            await self.chain.append(
                event_type="fira_accept",
                remote_did=remote_did,
                result="success",
                extra_data={"role": proposed_role, "fir_a_id": fir_a_id}
            )
            
            await self.ws.send_json({
                "type": "fira_response",
                "status": "accepted",
                "fir_a_id": fir_a_id,
                "remote_did": remote_did,
                "continuity_hash": initial_hash
            })
            
            print(f"[JIS] FIR/A accepted: {fir_a_id}")
        
        else:
            # Reject unknown roles
            await self.chain.append(
                event_type="fira_reject",
                remote_did=remote_did,
                result="rejected",
                extra_data={"role": proposed_role, "reason": "unknown_role"}
            )
            
            await self.ws.send_json({
                "type": "fira_response",
                "status": "rejected",
                "remote_did": remote_did,
                "reason": "unknown_role"
            })
            
            print(f"[JIS] FIR/A rejected: unknown role {proposed_role}")
    
    # -------------------------------------------------------------------------
    # Intent Handling
    # -------------------------------------------------------------------------
    
    async def _handle_intent(self, message: Dict):
        """Handle incoming intent"""
        sender_did = message.get("sender_did")
        intent_category = message.get("category")
        action = message.get("action")
        params = message.get("params", {})
        continuity_hash = message.get("continuity_hash")
        
        print(f"[JIS] Intent from {sender_did}: {intent_category}/{action}")
        
        # Verify the sender
        verification = await self.verify(
            sender_did=sender_did,
            intent_category=intent_category,
            continuity_hash=continuity_hash
        )
        
        if not verification.valid:
            print(f"[JIS] Intent rejected: {verification.reason}")
            await self._trigger_nir(sender_did, "invalid_intent", verification.reason)
            return
        
        # Find handler
        handler_key = f"{intent_category}:{action}"
        handler = self.intent_handlers.get(handler_key)
        
        if not handler:
            handler = self.intent_handlers.get(intent_category)
        
        if handler:
            try:
                result = await handler(
                    sender_did=sender_did,
                    role=verification.role,
                    action=action,
                    params=params
                )
                
                # Log success
                await self.chain.append(
                    event_type="intent_executed",
                    remote_did=sender_did,
                    intent=f"{intent_category}/{action}",
                    result="success"
                )
                
                # Update FIR/A
                if verification.fir_a:
                    await self.fira.update_interaction(
                        verification.fir_a.fir_a_id,
                        self.chain.current_hash
                    )
                
                # Send response
                await self.ws.send_json({
                    "type": "intent_response",
                    "request_id": message.get("request_id"),
                    "status": "success",
                    "result": result,
                    "continuity_hash": self.chain.current_hash
                })
                
            except Exception as e:
                print(f"[JIS] Intent handler error: {e}")
                await self.chain.append(
                    event_type="intent_error",
                    remote_did=sender_did,
                    intent=f"{intent_category}/{action}",
                    result="error",
                    extra_data={"error": str(e)}
                )
        else:
            print(f"[JIS] No handler for {intent_category}/{action}")
    
    async def verify(
        self,
        sender_did: str,
        intent_category: str,
        continuity_hash: str
    ) -> VerificationResult:
        """Verify an incoming intent"""
        
        # Check FIR/A relation
        relation = self.fira.get_by_did(sender_did)
        
        if not relation:
            return VerificationResult(
                valid=False,
                fir_a=None,
                role=None,
                reason="no_fira_relation"
            )
        
        # Check if intent is allowed
        if not self.fira.can_execute(relation, intent_category):
            return VerificationResult(
                valid=False,
                fir_a=relation,
                role=relation.role,
                reason="intent_not_allowed"
            )
        
        # Optionally verify continuity hash with Brein
        # (for high-security operations)
        
        return VerificationResult(
            valid=True,
            fir_a=relation,
            role=relation.role,
            reason=None
        )
    
    # -------------------------------------------------------------------------
    # NIR (Notify → Identify → Rectify/Revoke)
    # -------------------------------------------------------------------------
    
    async def _handle_nir(self, message: Dict):
        """Handle incoming NIR notification"""
        nir_type = message.get("nir_type")
        source_did = message.get("source_did")
        reason = message.get("reason")
        
        print(f"[JIS] NIR received: {nir_type} from {source_did}: {reason}")
        
        # Call registered handlers
        for handler in self.nir_handlers:
            await handler(nir_type, source_did, reason)
        
        # Log to chain
        await self.chain.append(
            event_type="nir_received",
            remote_did=source_did,
            result=nir_type,
            extra_data={"reason": reason}
        )
    
    async def _trigger_nir(self, target_did: str, nir_type: str, reason: str):
        """Trigger a NIR event"""
        print(f"[JIS] Triggering NIR: {nir_type} for {target_did}: {reason}")
        
        # Log to chain
        await self.chain.append(
            event_type="nir_triggered",
            remote_did=target_did,
            result=nir_type,
            extra_data={"reason": reason}
        )
        
        # Notify Brein
        if self.ws:
            await self.ws.send_json({
                "type": "nir",
                "nir_type": nir_type,
                "target_did": target_did,
                "source_did": self.identity.did,
                "reason": reason,
                "continuity_hash": self.chain.current_hash
            })
    
    # -------------------------------------------------------------------------
    # Handler Registration
    # -------------------------------------------------------------------------
    
    def on_intent(self, category: str, action: str = None):
        """Decorator to register an intent handler"""
        def decorator(func):
            key = f"{category}:{action}" if action else category
            self.intent_handlers[key] = func
            return func
        return decorator
    
    def on_nir(self, func):
        """Decorator to register a NIR handler"""
        self.nir_handlers.append(func)
        return func
    
    # -------------------------------------------------------------------------
    # Outgoing Communication
    # -------------------------------------------------------------------------
    
    async def send_intent(
        self,
        target_did: str,
        category: str,
        action: str,
        params: Dict = None
    ) -> Optional[Dict]:
        """Send an intent to another entity via Brein"""
        
        if not self.ws:
            print("[JIS] Not connected to WebSocket")
            return None
        
        request_id = str(uuid.uuid4())
        
        await self.ws.send_json({
            "type": "intent",
            "request_id": request_id,
            "sender_did": self.identity.did,
            "target_did": target_did,
            "category": category,
            "action": action,
            "params": params or {},
            "continuity_hash": self.chain.current_hash
        })
        
        # Log outgoing intent
        await self.chain.append(
            event_type="intent_sent",
            remote_did=target_did,
            intent=f"{category}/{action}",
            result="sent"
        )
        
        return {"request_id": request_id}
    
    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------
    
    async def shutdown(self):
        """Clean shutdown"""
        print("[JIS] Shutting down...")
        self._running = False
        
        if self.ws:
            await self.ws.close()
        
        if self.session:
            await self.session.close()
        
        await self.chain.save()
        await self.fira.save()
        
        print("[JIS] Shutdown complete")


# =============================================================================
# Singleton Instance
# =============================================================================

_client: Optional[JISClient] = None

def get_client() -> JISClient:
    """Get the JIS client singleton"""
    global _client
    if _client is None:
        _client = JISClient()
    return _client


# =============================================================================
# CLI for Testing
# =============================================================================

async def main():
    """Test the JIS client"""
    client = get_client()
    await client.initialize()
    
    # Example intent handler
    @client.on_intent("comfort")
    async def handle_comfort(sender_did, role, action, params):
        print(f"[HANDLER] Comfort intent from {role}: {action}")
        print(f"[HANDLER] Params: {params}")
        return {"status": "executed", "action": action}
    
    @client.on_intent("query")
    async def handle_query(sender_did, role, action, params):
        print(f"[HANDLER] Query from {role}: {action}")
        return {"status": "ok", "answer": "This is a test response"}
    
    @client.on_nir
    async def handle_nir(nir_type, source_did, reason):
        print(f"[NIR HANDLER] {nir_type} from {source_did}: {reason}")
    
    # Connect and run
    try:
        await client.connect_websocket()
    except KeyboardInterrupt:
        pass
    finally:
        await client.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
