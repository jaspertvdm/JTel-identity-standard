"""
Actuators Module for Raspberry Pi
==================================

Controls output devices:
- LED strips (WS2812B/NeoPixel)
- Status LEDs
- Audio output
- Relays

Author: Jasper van de Meent / JTel
"""

import asyncio
from dataclasses import dataclass
from typing import Optional, Tuple, List
from enum import Enum


# =============================================================================
# Color Definitions
# =============================================================================

class StatusColor(Enum):
    """Predefined status colors"""
    OFF = (0, 0, 0)
    WHITE = (255, 255, 255)
    WARM_WHITE = (255, 200, 150)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)
    YELLOW = (255, 255, 0)
    ORANGE = (255, 165, 0)
    PURPLE = (128, 0, 128)
    CYAN = (0, 255, 255)
    
    # Status indicators
    CONNECTED = (0, 255, 0)
    DISCONNECTED = (255, 0, 0)
    PROCESSING = (0, 0, 255)
    WARNING = (255, 165, 0)
    ERROR = (255, 0, 0)
    EMERGENCY = (255, 0, 0)


@dataclass
class LightState:
    """Current state of a light"""
    on: bool
    brightness: float  # 0.0 - 1.0
    color: Tuple[int, int, int]
    effect: Optional[str] = None


# =============================================================================
# LED Strip Controller (NeoPixel/WS2812B)
# =============================================================================

class LEDStripController:
    """Controls WS2812B/NeoPixel LED strips"""
    
    def __init__(self, pin: int = 18, num_leds: int = 30):
        self.pin = pin
        self.num_leds = num_leds
        self.pixels = None
        self.available = False
        self.current_state = LightState(False, 1.0, StatusColor.OFF.value)
        
        self._effect_task: Optional[asyncio.Task] = None
        self._init_strip()
    
    def _init_strip(self):
        """Initialize the LED strip"""
        try:
            import board
            import neopixel
            
            pin_map = {
                10: board.D10,
                12: board.D12,
                18: board.D18,
                21: board.D21
            }
            
            if self.pin in pin_map:
                self.pixels = neopixel.NeoPixel(
                    pin_map[self.pin],
                    self.num_leds,
                    brightness=1.0,
                    auto_write=False
                )
                self.available = True
                print(f"[ACTUATOR] LED strip initialized: {self.num_leds} LEDs on pin {self.pin}")
            else:
                print(f"[ACTUATOR] Invalid pin for NeoPixel: {self.pin}")
                
        except ImportError:
            print("[ACTUATOR] neopixel not available - LED strip in simulation mode")
        except Exception as e:
            print(f"[ACTUATOR] LED strip init error: {e}")
    
    def _apply_brightness(self, color: Tuple[int, int, int]) -> Tuple[int, int, int]:
        """Apply brightness to color"""
        b = self.current_state.brightness
        return (int(color[0] * b), int(color[1] * b), int(color[2] * b))
    
    async def set_color(self, color: Tuple[int, int, int], brightness: float = None):
        """Set all LEDs to a color"""
        self._stop_effect()
        
        if brightness is not None:
            self.current_state.brightness = max(0.0, min(1.0, brightness))
        
        self.current_state.color = color
        self.current_state.on = color != StatusColor.OFF.value
        
        adjusted = self._apply_brightness(color)
        
        if self.available:
            self.pixels.fill(adjusted)
            self.pixels.show()
        else:
            print(f"[ACTUATOR] LED: {adjusted}")
    
    async def set_status(self, status: StatusColor, brightness: float = None):
        """Set status color"""
        await self.set_color(status.value, brightness)
    
    async def turn_off(self):
        """Turn off all LEDs"""
        await self.set_color(StatusColor.OFF.value)
    
    async def turn_on(self, brightness: float = None):
        """Turn on with current or warm white color"""
        color = self.current_state.color
        if color == StatusColor.OFF.value:
            color = StatusColor.WARM_WHITE.value
        await self.set_color(color, brightness)
    
    # -------------------------------------------------------------------------
    # Effects
    # -------------------------------------------------------------------------
    
    def _stop_effect(self):
        """Stop any running effect"""
        if self._effect_task and not self._effect_task.done():
            self._effect_task.cancel()
        self.current_state.effect = None
    
    async def blink(self, color: Tuple[int, int, int], times: int = 3, interval: float = 0.3):
        """Blink effect"""
        self._stop_effect()
        self.current_state.effect = "blink"
        
        for _ in range(times):
            await self.set_color(color)
            await asyncio.sleep(interval)
            await self.set_color(StatusColor.OFF.value)
            await asyncio.sleep(interval)
        
        self.current_state.effect = None
    
    async def pulse(self, color: Tuple[int, int, int], duration: float = 2.0):
        """Pulse effect (fade in and out)"""
        self._stop_effect()
        self.current_state.effect = "pulse"
        
        steps = 50
        step_duration = duration / (steps * 2)
        
        # Fade in
        for i in range(steps):
            brightness = i / steps
            await self.set_color(color, brightness)
            await asyncio.sleep(step_duration)
        
        # Fade out
        for i in range(steps, 0, -1):
            brightness = i / steps
            await self.set_color(color, brightness)
            await asyncio.sleep(step_duration)
        
        self.current_state.effect = None
    
    async def emergency_flash(self, duration: float = 10.0):
        """Emergency flashing red"""
        self._stop_effect()
        self.current_state.effect = "emergency"
        
        end_time = asyncio.get_event_loop().time() + duration
        
        while asyncio.get_event_loop().time() < end_time:
            await self.set_color(StatusColor.RED.value, 1.0)
            await asyncio.sleep(0.1)
            await self.set_color(StatusColor.OFF.value)
            await asyncio.sleep(0.1)
        
        self.current_state.effect = None
    
    async def mood_transition(self, target_color: Tuple[int, int, int], duration: float = 2.0):
        """Smooth transition to target color"""
        self._stop_effect()
        self.current_state.effect = "transition"
        
        start_color = self.current_state.color
        steps = 50
        step_duration = duration / steps
        
        for i in range(steps + 1):
            ratio = i / steps
            r = int(start_color[0] + (target_color[0] - start_color[0]) * ratio)
            g = int(start_color[1] + (target_color[1] - start_color[1]) * ratio)
            b = int(start_color[2] + (target_color[2] - start_color[2]) * ratio)
            
            await self.set_color((r, g, b))
            await asyncio.sleep(step_duration)
        
        self.current_state.effect = None


# =============================================================================
# Simple Status LED
# =============================================================================

class StatusLED:
    """Simple single-color status LED"""
    
    def __init__(self, pin: int, gpio):
        self.pin = pin
        self.gpio = gpio
        self.on = False
        
        if gpio.available:
            gpio.setup_output(pin)
    
    async def turn_on(self):
        """Turn on the LED"""
        self.on = True
        self.gpio.write(self.pin, True)
    
    async def turn_off(self):
        """Turn off the LED"""
        self.on = False
        self.gpio.write(self.pin, False)
    
    async def toggle(self):
        """Toggle the LED"""
        if self.on:
            await self.turn_off()
        else:
            await self.turn_on()
    
    async def blink(self, times: int = 3, interval: float = 0.2):
        """Blink the LED"""
        for _ in range(times):
            await self.turn_on()
            await asyncio.sleep(interval)
            await self.turn_off()
            await asyncio.sleep(interval)


# =============================================================================
# Audio Controller
# =============================================================================

class AudioController:
    """Controls audio output"""
    
    def __init__(self):
        self.available = False
        self.pygame_available = False
        self.volume = 0.7
        
        self._init_audio()
    
    def _init_audio(self):
        """Initialize audio system"""
        try:
            import pygame
            pygame.mixer.init()
            self.pygame_available = True
            self.available = True
            print("[ACTUATOR] Audio initialized via pygame")
        except:
            pass
        
        if not self.available:
            try:
                # Try simpleaudio as fallback
                import simpleaudio
                self.available = True
                print("[ACTUATOR] Audio initialized via simpleaudio")
            except:
                print("[ACTUATOR] No audio system available")
    
    async def play_sound(self, sound_path: str):
        """Play a sound file"""
        if not self.available:
            print(f"[ACTUATOR] Would play: {sound_path}")
            return
        
        try:
            if self.pygame_available:
                import pygame
                pygame.mixer.music.load(sound_path)
                pygame.mixer.music.set_volume(self.volume)
                pygame.mixer.music.play()
            else:
                import simpleaudio as sa
                wave_obj = sa.WaveObject.from_wave_file(sound_path)
                wave_obj.play()
        except Exception as e:
            print(f"[ACTUATOR] Audio playback error: {e}")
    
    async def play_tone(self, frequency: int = 440, duration: float = 0.5):
        """Play a simple tone"""
        if not self.available:
            print(f"[ACTUATOR] Would play tone: {frequency}Hz for {duration}s")
            return
        
        # Generate and play tone using numpy if available
        try:
            import numpy as np
            
            sample_rate = 44100
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            tone = np.sin(frequency * t * 2 * np.pi)
            audio = (tone * 32767 * self.volume).astype(np.int16)
            
            if self.pygame_available:
                import pygame
                sound = pygame.sndarray.make_sound(
                    np.column_stack((audio, audio))
                )
                sound.play()
                await asyncio.sleep(duration)
            else:
                import simpleaudio as sa
                play_obj = sa.play_buffer(audio, 1, 2, sample_rate)
                play_obj.wait_done()
                
        except ImportError:
            print("[ACTUATOR] numpy not available for tone generation")
    
    async def alert_sound(self):
        """Play alert sound"""
        await self.play_tone(880, 0.2)
        await asyncio.sleep(0.1)
        await self.play_tone(880, 0.2)
    
    async def success_sound(self):
        """Play success sound"""
        await self.play_tone(523, 0.15)
        await self.play_tone(659, 0.15)
        await self.play_tone(784, 0.3)
    
    async def error_sound(self):
        """Play error sound"""
        await self.play_tone(200, 0.3)
        await asyncio.sleep(0.1)
        await self.play_tone(200, 0.3)
    
    async def emergency_siren(self, duration: float = 5.0):
        """Play emergency siren"""
        end_time = asyncio.get_event_loop().time() + duration
        
        while asyncio.get_event_loop().time() < end_time:
            await self.play_tone(800, 0.25)
            await self.play_tone(600, 0.25)
    
    def set_volume(self, volume: float):
        """Set volume (0.0 - 1.0)"""
        self.volume = max(0.0, min(1.0, volume))
        
        if self.pygame_available:
            import pygame
            pygame.mixer.music.set_volume(self.volume)


# =============================================================================
# Relay Controller
# =============================================================================

class RelayController:
    """Controls relay switches"""
    
    def __init__(self, pins: List[int], gpio, active_low: bool = True):
        self.pins = pins
        self.gpio = gpio
        self.active_low = active_low
        self.states = {pin: False for pin in pins}
        
        for pin in pins:
            if gpio.available:
                gpio.setup_output(pin)
                # Initialize to off
                gpio.write(pin, active_low)  # Active low = HIGH is off
    
    async def set_relay(self, pin: int, on: bool):
        """Set a relay state"""
        if pin not in self.pins:
            return
        
        self.states[pin] = on
        
        # Active low: ON = LOW, OFF = HIGH
        gpio_value = not on if self.active_low else on
        self.gpio.write(pin, gpio_value)
        
        print(f"[ACTUATOR] Relay {pin}: {'ON' if on else 'OFF'}")
    
    async def toggle_relay(self, pin: int):
        """Toggle a relay"""
        if pin in self.pins:
            await self.set_relay(pin, not self.states[pin])
    
    async def all_off(self):
        """Turn all relays off"""
        for pin in self.pins:
            await self.set_relay(pin, False)
    
    async def all_on(self):
        """Turn all relays on"""
        for pin in self.pins:
            await self.set_relay(pin, True)


# =============================================================================
# Unified Actuator Manager
# =============================================================================

class ActuatorManager:
    """Manages all actuators"""
    
    def __init__(self, gpio=None):
        self.gpio = gpio
        self.led_strip: Optional[LEDStripController] = None
        self.status_led: Optional[StatusLED] = None
        self.audio: Optional[AudioController] = None
        self.relay: Optional[RelayController] = None
    
    def setup_led_strip(self, pin: int = 18, num_leds: int = 30):
        """Setup LED strip"""
        self.led_strip = LEDStripController(pin, num_leds)
        return self.led_strip
    
    def setup_status_led(self, pin: int):
        """Setup status LED"""
        if self.gpio:
            self.status_led = StatusLED(pin, self.gpio)
        return self.status_led
    
    def setup_audio(self):
        """Setup audio controller"""
        self.audio = AudioController()
        return self.audio
    
    def setup_relay(self, pins: List[int], active_low: bool = True):
        """Setup relay controller"""
        if self.gpio:
            self.relay = RelayController(pins, self.gpio, active_low)
        return self.relay
    
    # -------------------------------------------------------------------------
    # High-level commands (for Humotica)
    # -------------------------------------------------------------------------
    
    async def set_mood(self, mood: str, brightness: float = 0.7):
        """Set mood lighting"""
        
        mood_colors = {
            "relaxed": (255, 180, 100),
            "energetic": (255, 255, 255),
            "romantic": (255, 100, 100),
            "focus": (200, 200, 255),
            "movie": (50, 50, 100),
            "party": (255, 0, 255),
            "sleep": (50, 30, 0),
            "morning": (255, 220, 180),
            "evening": (255, 150, 80)
        }
        
        color = mood_colors.get(mood.lower(), StatusColor.WARM_WHITE.value)
        
        if self.led_strip:
            await self.led_strip.mood_transition(color, duration=1.5)
            await self.led_strip.set_color(color, brightness)
        
        if self.audio:
            await self.audio.success_sound()
    
    async def alert(self, level: str = "info"):
        """Show alert"""
        
        if level == "info":
            if self.led_strip:
                await self.led_strip.blink(StatusColor.BLUE.value, 2)
            if self.audio:
                await self.audio.alert_sound()
        
        elif level == "warning":
            if self.led_strip:
                await self.led_strip.blink(StatusColor.ORANGE.value, 3)
            if self.audio:
                await self.audio.alert_sound()
        
        elif level == "error":
            if self.led_strip:
                await self.led_strip.blink(StatusColor.RED.value, 3)
            if self.audio:
                await self.audio.error_sound()
        
        elif level == "emergency":
            # Run both in parallel
            tasks = []
            if self.led_strip:
                tasks.append(self.led_strip.emergency_flash(5.0))
            if self.audio:
                tasks.append(self.audio.emergency_siren(5.0))
            
            if tasks:
                await asyncio.gather(*tasks)
    
    async def indicate_status(self, status: str):
        """Show status indication"""
        
        status_map = {
            "connected": StatusColor.CONNECTED,
            "disconnected": StatusColor.DISCONNECTED,
            "processing": StatusColor.PROCESSING,
            "ready": StatusColor.GREEN,
            "busy": StatusColor.ORANGE,
            "error": StatusColor.ERROR
        }
        
        color = status_map.get(status.lower(), StatusColor.WHITE)
        
        if self.led_strip:
            await self.led_strip.set_status(color, 0.5)
        
        if self.status_led:
            if status in ["connected", "ready"]:
                await self.status_led.turn_on()
            else:
                await self.status_led.blink(2)


# =============================================================================
# CLI for Testing
# =============================================================================

async def main():
    """Test actuators"""
    
    manager = ActuatorManager()
    
    # Setup (will run in simulation mode without hardware)
    manager.setup_led_strip(pin=18, num_leds=30)
    manager.setup_audio()
    
    print("[TEST] Testing actuators...")
    
    # Test mood lighting
    print("\n[TEST] Mood: relaxed")
    await manager.set_mood("relaxed")
    await asyncio.sleep(2)
    
    print("\n[TEST] Mood: energetic")
    await manager.set_mood("energetic")
    await asyncio.sleep(2)
    
    # Test alerts
    print("\n[TEST] Alert: info")
    await manager.alert("info")
    await asyncio.sleep(1)
    
    print("\n[TEST] Alert: warning")
    await manager.alert("warning")
    await asyncio.sleep(1)
    
    # Test status
    print("\n[TEST] Status: connected")
    await manager.indicate_status("connected")
    await asyncio.sleep(2)
    
    print("\n[TEST] Status: processing")
    await manager.indicate_status("processing")
    await asyncio.sleep(2)
    
    # Turn off
    if manager.led_strip:
        await manager.led_strip.turn_off()
    
    print("\n[TEST] Done!")


if __name__ == "__main__":
    asyncio.run(main())
