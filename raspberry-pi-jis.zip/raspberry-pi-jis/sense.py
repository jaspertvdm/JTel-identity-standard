"""
Sense Module for Raspberry Pi
==============================

Integrates hardware sensors and implements sense rules for:
- Environmental monitoring (temp, humidity, motion)
- Device state tracking
- Anomaly detection
- Trigger generation

Author: Jasper van de Meent / JTel
"""

import asyncio
import json
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Callable, Any
from enum import Enum
from pathlib import Path


# =============================================================================
# Sensor Abstraction
# =============================================================================

class SensorType(Enum):
    TEMPERATURE = "temperature"
    HUMIDITY = "humidity"
    MOTION = "motion"
    LIGHT = "light"
    SOUND = "sound"
    BUTTON = "button"
    SMOKE = "smoke"
    DOOR = "door"


@dataclass
class SensorReading:
    """A single sensor reading"""
    sensor_id: str
    sensor_type: SensorType
    value: Any
    unit: str
    timestamp: str
    confidence: float = 1.0


@dataclass
class SenseRule:
    """A rule that triggers based on sensor conditions"""
    rule_id: str
    name: str
    conditions: List[Dict]  # [{sensor_type, operator, threshold}]
    logic: str  # "and" or "or"
    action: str  # Intent category to trigger
    action_params: Dict
    cooldown_seconds: int = 60
    last_triggered: Optional[str] = None
    enabled: bool = True


# =============================================================================
# Hardware Interfaces (GPIO)
# =============================================================================

class GPIOInterface:
    """Interface to Raspberry Pi GPIO"""
    
    def __init__(self):
        self.available = False
        self._gpio = None
        self._init_gpio()
    
    def _init_gpio(self):
        """Initialize GPIO library"""
        try:
            import RPi.GPIO as GPIO
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            self._gpio = GPIO
            self.available = True
            print("[SENSE] GPIO initialized")
        except ImportError:
            print("[SENSE] RPi.GPIO not available - running in simulation mode")
        except Exception as e:
            print(f"[SENSE] GPIO init error: {e}")
    
    def setup_input(self, pin: int, pull_up: bool = True):
        """Setup a pin as input"""
        if self.available:
            pud = self._gpio.PUD_UP if pull_up else self._gpio.PUD_DOWN
            self._gpio.setup(pin, self._gpio.IN, pull_up_down=pud)
    
    def setup_output(self, pin: int):
        """Setup a pin as output"""
        if self.available:
            self._gpio.setup(pin, self._gpio.OUT)
    
    def read(self, pin: int) -> bool:
        """Read a digital pin"""
        if self.available:
            return self._gpio.input(pin) == self._gpio.HIGH
        return False
    
    def write(self, pin: int, value: bool):
        """Write to a digital pin"""
        if self.available:
            self._gpio.output(pin, self._gpio.HIGH if value else self._gpio.LOW)
    
    def cleanup(self):
        """Cleanup GPIO"""
        if self.available:
            self._gpio.cleanup()


# =============================================================================
# Sensor Implementations
# =============================================================================

class BaseSensor:
    """Base class for sensors"""
    
    def __init__(self, sensor_id: str, sensor_type: SensorType):
        self.sensor_id = sensor_id
        self.sensor_type = sensor_type
        self.last_reading: Optional[SensorReading] = None
    
    async def read(self) -> Optional[SensorReading]:
        """Read sensor value - override in subclass"""
        raise NotImplementedError


class DHT22Sensor(BaseSensor):
    """DHT22 Temperature and Humidity sensor"""
    
    def __init__(self, sensor_id: str, pin: int):
        super().__init__(sensor_id, SensorType.TEMPERATURE)
        self.pin = pin
        self._dht = None
        self._init_dht()
    
    def _init_dht(self):
        try:
            import adafruit_dht
            import board
            pin_map = {4: board.D4, 17: board.D17, 18: board.D18, 27: board.D27}
            if self.pin in pin_map:
                self._dht = adafruit_dht.DHT22(pin_map[self.pin])
                print(f"[SENSE] DHT22 initialized on pin {self.pin}")
        except ImportError:
            print("[SENSE] adafruit_dht not available")
        except Exception as e:
            print(f"[SENSE] DHT22 init error: {e}")
    
    async def read(self) -> Optional[SensorReading]:
        if self._dht:
            try:
                temp = self._dht.temperature
                humidity = self._dht.humidity
                
                self.last_reading = SensorReading(
                    sensor_id=self.sensor_id,
                    sensor_type=SensorType.TEMPERATURE,
                    value={"temperature": temp, "humidity": humidity},
                    unit="celsius/%",
                    timestamp=datetime.utcnow().isoformat()
                )
                return self.last_reading
            except Exception as e:
                print(f"[SENSE] DHT22 read error: {e}")
        
        # Simulation mode
        import random
        self.last_reading = SensorReading(
            sensor_id=self.sensor_id,
            sensor_type=SensorType.TEMPERATURE,
            value={"temperature": 21.0 + random.uniform(-2, 2), 
                   "humidity": 45.0 + random.uniform(-5, 5)},
            unit="celsius/%",
            timestamp=datetime.utcnow().isoformat(),
            confidence=0.5  # Lower confidence for simulated
        )
        return self.last_reading


class PIRSensor(BaseSensor):
    """PIR Motion sensor"""
    
    def __init__(self, sensor_id: str, pin: int, gpio: GPIOInterface):
        super().__init__(sensor_id, SensorType.MOTION)
        self.pin = pin
        self.gpio = gpio
        self.gpio.setup_input(pin, pull_up=False)
    
    async def read(self) -> Optional[SensorReading]:
        motion = self.gpio.read(self.pin) if self.gpio.available else False
        
        self.last_reading = SensorReading(
            sensor_id=self.sensor_id,
            sensor_type=SensorType.MOTION,
            value=motion,
            unit="boolean",
            timestamp=datetime.utcnow().isoformat()
        )
        return self.last_reading


class ButtonSensor(BaseSensor):
    """Physical button sensor"""
    
    def __init__(self, sensor_id: str, pin: int, gpio: GPIOInterface):
        super().__init__(sensor_id, SensorType.BUTTON)
        self.pin = pin
        self.gpio = gpio
        self.gpio.setup_input(pin, pull_up=True)
        self._last_state = False
    
    async def read(self) -> Optional[SensorReading]:
        pressed = not self.gpio.read(self.pin) if self.gpio.available else False
        
        # Detect press event (transition from not pressed to pressed)
        event = pressed and not self._last_state
        self._last_state = pressed
        
        self.last_reading = SensorReading(
            sensor_id=self.sensor_id,
            sensor_type=SensorType.BUTTON,
            value={"pressed": pressed, "event": event},
            unit="boolean",
            timestamp=datetime.utcnow().isoformat()
        )
        return self.last_reading


class SimulatedSmokeSensor(BaseSensor):
    """Simulated smoke sensor for demo"""
    
    def __init__(self, sensor_id: str):
        super().__init__(sensor_id, SensorType.SMOKE)
        self._trigger_smoke = False
    
    def trigger(self):
        """Manually trigger smoke for demo"""
        self._trigger_smoke = True
    
    def reset(self):
        """Reset smoke trigger"""
        self._trigger_smoke = False
    
    async def read(self) -> Optional[SensorReading]:
        self.last_reading = SensorReading(
            sensor_id=self.sensor_id,
            sensor_type=SensorType.SMOKE,
            value=self._trigger_smoke,
            unit="boolean",
            timestamp=datetime.utcnow().isoformat()
        )
        return self.last_reading


# =============================================================================
# Sense Engine
# =============================================================================

class SenseEngine:
    """Main sense engine that monitors sensors and evaluates rules"""
    
    def __init__(self):
        self.gpio = GPIOInterface()
        self.sensors: Dict[str, BaseSensor] = {}
        self.rules: Dict[str, SenseRule] = {}
        self.readings_history: List[SensorReading] = []
        self.max_history = 1000
        
        self.trigger_callbacks: List[Callable] = []
        
        self._running = False
        self._poll_interval = 1.0  # seconds
    
    # -------------------------------------------------------------------------
    # Sensor Management
    # -------------------------------------------------------------------------
    
    def add_sensor(self, sensor: BaseSensor):
        """Add a sensor to the engine"""
        self.sensors[sensor.sensor_id] = sensor
        print(f"[SENSE] Added sensor: {sensor.sensor_id} ({sensor.sensor_type.value})")
    
    def add_dht22(self, sensor_id: str, pin: int) -> DHT22Sensor:
        """Add a DHT22 temperature/humidity sensor"""
        sensor = DHT22Sensor(sensor_id, pin)
        self.add_sensor(sensor)
        return sensor
    
    def add_pir(self, sensor_id: str, pin: int) -> PIRSensor:
        """Add a PIR motion sensor"""
        sensor = PIRSensor(sensor_id, pin, self.gpio)
        self.add_sensor(sensor)
        return sensor
    
    def add_button(self, sensor_id: str, pin: int) -> ButtonSensor:
        """Add a button sensor"""
        sensor = ButtonSensor(sensor_id, pin, self.gpio)
        self.add_sensor(sensor)
        return sensor
    
    def add_simulated_smoke(self, sensor_id: str) -> SimulatedSmokeSensor:
        """Add a simulated smoke sensor"""
        sensor = SimulatedSmokeSensor(sensor_id)
        self.add_sensor(sensor)
        return sensor
    
    # -------------------------------------------------------------------------
    # Rule Management
    # -------------------------------------------------------------------------
    
    def add_rule(self, rule: SenseRule):
        """Add a sense rule"""
        self.rules[rule.rule_id] = rule
        print(f"[SENSE] Added rule: {rule.name}")
    
    def create_rule(
        self,
        rule_id: str,
        name: str,
        conditions: List[Dict],
        action: str,
        action_params: Dict = None,
        logic: str = "and",
        cooldown: int = 60
    ) -> SenseRule:
        """Create and add a sense rule"""
        rule = SenseRule(
            rule_id=rule_id,
            name=name,
            conditions=conditions,
            logic=logic,
            action=action,
            action_params=action_params or {},
            cooldown_seconds=cooldown
        )
        self.add_rule(rule)
        return rule
    
    def load_rules_from_file(self, path: Path):
        """Load rules from JSON file"""
        if path.exists():
            with open(path) as f:
                data = json.load(f)
                for rule_data in data.get("rules", []):
                    self.add_rule(SenseRule(**rule_data))
    
    # -------------------------------------------------------------------------
    # Rule Evaluation
    # -------------------------------------------------------------------------
    
    def _evaluate_condition(self, condition: Dict, readings: Dict[str, SensorReading]) -> bool:
        """Evaluate a single condition"""
        sensor_type = condition.get("sensor_type")
        operator = condition.get("operator")
        threshold = condition.get("threshold")
        field = condition.get("field")  # For nested values like temperature
        
        # Find matching sensor reading
        for reading in readings.values():
            if reading.sensor_type.value == sensor_type:
                value = reading.value
                
                # Handle nested values
                if field and isinstance(value, dict):
                    value = value.get(field)
                
                if value is None:
                    continue
                
                # Evaluate operator
                if operator == ">" and value > threshold:
                    return True
                elif operator == "<" and value < threshold:
                    return True
                elif operator == ">=" and value >= threshold:
                    return True
                elif operator == "<=" and value <= threshold:
                    return True
                elif operator == "==" and value == threshold:
                    return True
                elif operator == "!=" and value != threshold:
                    return True
                elif operator == "is_true" and value:
                    return True
                elif operator == "is_false" and not value:
                    return True
        
        return False
    
    def _evaluate_rule(self, rule: SenseRule, readings: Dict[str, SensorReading]) -> bool:
        """Evaluate a rule against current readings"""
        if not rule.enabled:
            return False
        
        # Check cooldown
        if rule.last_triggered:
            last = datetime.fromisoformat(rule.last_triggered)
            elapsed = (datetime.utcnow() - last).total_seconds()
            if elapsed < rule.cooldown_seconds:
                return False
        
        # Evaluate conditions
        results = [self._evaluate_condition(c, readings) for c in rule.conditions]
        
        if rule.logic == "and":
            return all(results)
        elif rule.logic == "or":
            return any(results)
        
        return False
    
    # -------------------------------------------------------------------------
    # Main Loop
    # -------------------------------------------------------------------------
    
    async def start(self):
        """Start the sense engine"""
        self._running = True
        print("[SENSE] Engine started")
        
        while self._running:
            try:
                # Read all sensors
                readings = {}
                for sensor_id, sensor in self.sensors.items():
                    reading = await sensor.read()
                    if reading:
                        readings[sensor_id] = reading
                        self.readings_history.append(reading)
                
                # Trim history
                if len(self.readings_history) > self.max_history:
                    self.readings_history = self.readings_history[-self.max_history:]
                
                # Evaluate rules
                for rule_id, rule in self.rules.items():
                    if self._evaluate_rule(rule, readings):
                        await self._trigger_rule(rule, readings)
                
            except Exception as e:
                print(f"[SENSE] Error in main loop: {e}")
            
            await asyncio.sleep(self._poll_interval)
    
    async def _trigger_rule(self, rule: SenseRule, readings: Dict[str, SensorReading]):
        """Trigger a rule action"""
        print(f"[SENSE] Rule triggered: {rule.name}")
        
        rule.last_triggered = datetime.utcnow().isoformat()
        
        # Gather context
        context = {
            "rule_id": rule.rule_id,
            "rule_name": rule.name,
            "readings": {k: asdict(v) for k, v in readings.items()},
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Call registered callbacks
        for callback in self.trigger_callbacks:
            try:
                await callback(rule.action, rule.action_params, context)
            except Exception as e:
                print(f"[SENSE] Callback error: {e}")
    
    def on_trigger(self, callback: Callable):
        """Register a callback for rule triggers"""
        self.trigger_callbacks.append(callback)
    
    def stop(self):
        """Stop the sense engine"""
        self._running = False
        self.gpio.cleanup()
        print("[SENSE] Engine stopped")
    
    # -------------------------------------------------------------------------
    # Queries
    # -------------------------------------------------------------------------
    
    def get_current_readings(self) -> Dict[str, SensorReading]:
        """Get current readings from all sensors"""
        return {sid: s.last_reading for sid, s in self.sensors.items() if s.last_reading}
    
    def get_reading_history(self, sensor_type: SensorType = None, limit: int = 100) -> List[SensorReading]:
        """Get reading history, optionally filtered by type"""
        history = self.readings_history[-limit:]
        if sensor_type:
            history = [r for r in history if r.sensor_type == sensor_type]
        return history


# =============================================================================
# Demo Setup
# =============================================================================

def create_demo_sense_engine() -> SenseEngine:
    """Create a sense engine configured for demo"""
    engine = SenseEngine()
    
    # Add sensors (using simulation if hardware not available)
    engine.add_dht22("temp_living", pin=4)
    engine.add_simulated_smoke("smoke_kitchen")
    
    # Add demo rules
    engine.create_rule(
        rule_id="high_temp",
        name="High Temperature Alert",
        conditions=[
            {"sensor_type": "temperature", "field": "temperature", "operator": ">", "threshold": 28}
        ],
        action="comfort",
        action_params={"action": "cool_down"},
        cooldown=300
    )
    
    engine.create_rule(
        rule_id="smoke_detected",
        name="Smoke Detected - Emergency",
        conditions=[
            {"sensor_type": "smoke", "operator": "is_true", "threshold": None}
        ],
        action="emergency",
        action_params={"type": "fire", "action": "alert_all"},
        cooldown=10
    )
    
    engine.create_rule(
        rule_id="comfortable_temp",
        name="Comfortable Temperature",
        conditions=[
            {"sensor_type": "temperature", "field": "temperature", "operator": ">=", "threshold": 20},
            {"sensor_type": "temperature", "field": "temperature", "operator": "<=", "threshold": 24}
        ],
        logic="and",
        action="system",
        action_params={"action": "log", "message": "Temperature comfortable"},
        cooldown=600
    )
    
    return engine


# =============================================================================
# CLI for Testing
# =============================================================================

async def main():
    """Test the sense engine"""
    engine = create_demo_sense_engine()
    
    # Register trigger callback
    @engine.on_trigger
    async def handle_trigger(action, params, context):
        print(f"[TRIGGER] Action: {action}")
        print(f"[TRIGGER] Params: {params}")
        print(f"[TRIGGER] Context: {json.dumps(context, indent=2, default=str)}")
    
    # Start engine
    try:
        await engine.start()
    except KeyboardInterrupt:
        pass
    finally:
        engine.stop()


if __name__ == "__main__":
    asyncio.run(main())
