#!/usr/bin/env python3
"""
JTel Kit - Raspberry Pi Demo Application
=========================================

Main application that integrates:
- JIS Client (identity, FIR/A, continuity)
- Sense Engine (sensors, rules)
- LLM Assistant (natural language)
- Actuators (lights, audio)

This creates a complete demo of the JTel ecosystem
running on a Raspberry Pi edge device.

Author: Jasper van de Meent / JTel
Usage: python main.py
"""

import asyncio
import json
import signal
from datetime import datetime
from typing import Dict, Any

# Local modules
from jis_client import JISClient, get_client, Config as JISConfig
from sense import SenseEngine, create_demo_sense_engine
from llm_assistant import LLMAssistant
from actuators import ActuatorManager, StatusColor


# =============================================================================
# Configuration
# =============================================================================

class AppConfig:
    """Application configuration"""
    
    # Device info
    DEVICE_NAME = "Home-Pi"
    DEVICE_LOCATION = "Woonkamer"
    
    # Hardware pins (adjust for your setup)
    LED_STRIP_PIN = 18
    LED_COUNT = 30
    STATUS_LED_PIN = 17
    PIR_PIN = 27
    DHT_PIN = 4
    BUTTON_PIN = 22
    
    # Features to enable
    ENABLE_LLM = True
    ENABLE_SENSE = True
    ENABLE_ACTUATORS = True
    ENABLE_VOICE = False  # Set True if you have mic/speaker


# =============================================================================
# Main Application
# =============================================================================

class JTelPiApp:
    """Main application class"""
    
    def __init__(self):
        self.jis: JISClient = None
        self.sense: SenseEngine = None
        self.llm: LLMAssistant = None
        self.actuators: ActuatorManager = None
        
        self._running = False
        self._tasks = []
    
    # -------------------------------------------------------------------------
    # Initialization
    # -------------------------------------------------------------------------
    
    async def initialize(self):
        """Initialize all components"""
        print("=" * 60)
        print("  JTel Kit - Raspberry Pi Demo")
        print("  Powered by context, driven by intent")
        print("=" * 60)
        print()
        
        # Initialize JIS client (core - always enabled)
        print("[INIT] Starting JIS client...")
        self.jis = get_client()
        await self.jis.initialize()
        
        # Initialize actuators
        if AppConfig.ENABLE_ACTUATORS:
            print("[INIT] Setting up actuators...")
            self.actuators = ActuatorManager()
            self.actuators.setup_led_strip(
                pin=AppConfig.LED_STRIP_PIN,
                num_leds=AppConfig.LED_COUNT
            )
            self.actuators.setup_audio()
            
            # Show startup indication
            await self.actuators.indicate_status("processing")
        
        # Initialize sense engine
        if AppConfig.ENABLE_SENSE:
            print("[INIT] Starting Sense engine...")
            self.sense = create_demo_sense_engine()
            
            # Register sense trigger handler
            @self.sense.on_trigger
            async def handle_sense_trigger(action, params, context):
                await self._handle_sense_trigger(action, params, context)
        
        # Initialize LLM assistant
        if AppConfig.ENABLE_LLM:
            print("[INIT] Starting LLM assistant...")
            self.llm = LLMAssistant()
            await self.llm.initialize()
            
            # Set context for LLM
            self.llm.set_context("device_name", AppConfig.DEVICE_NAME)
            self.llm.set_context("location", AppConfig.DEVICE_LOCATION)
            
            # Register intent callbacks
            self._register_llm_callbacks()
        
        # Register JIS intent handlers
        self._register_jis_handlers()
        
        # Show ready status
        if self.actuators:
            await self.actuators.indicate_status("connected")
            if self.actuators.audio:
                await self.actuators.audio.success_sound()
        
        print()
        print("[INIT] Initialization complete!")
        print(f"[INIT] Device DID: {self.jis.identity.did}")
        print()
    
    def _register_jis_handlers(self):
        """Register JIS intent handlers"""
        
        @self.jis.on_intent("comfort")
        async def handle_comfort(sender_did, role, action, params):
            print(f"[JIS] Comfort intent from {role}: {action}")
            return await self._execute_comfort(action, params)
        
        @self.jis.on_intent("query")
        async def handle_query(sender_did, role, action, params):
            print(f"[JIS] Query from {role}: {action}")
            return await self._execute_query(action, params)
        
        @self.jis.on_intent("emergency")
        async def handle_emergency(sender_did, role, action, params):
            print(f"[JIS] EMERGENCY from {role}: {action}")
            return await self._execute_emergency(action, params)
        
        @self.jis.on_intent("system")
        async def handle_system(sender_did, role, action, params):
            print(f"[JIS] System command from {role}: {action}")
            return await self._execute_system(action, params)
        
        @self.jis.on_nir
        async def handle_nir(nir_type, source_did, reason):
            print(f"[JIS] NIR: {nir_type} from {source_did}")
            if self.actuators:
                await self.actuators.alert("warning")
    
    def _register_llm_callbacks(self):
        """Register LLM intent callbacks"""
        
        @self.llm.on_intent("comfort")
        async def on_comfort_intent(intent):
            await self._execute_comfort(
                intent.get("action"),
                intent.get("params", {})
            )
        
        @self.llm.on_intent("emergency")
        async def on_emergency_intent(intent):
            await self._execute_emergency(
                intent.get("action"),
                intent.get("params", {})
            )
    
    # -------------------------------------------------------------------------
    # Intent Execution
    # -------------------------------------------------------------------------
    
    async def _execute_comfort(self, action: str, params: Dict) -> Dict:
        """Execute comfort-related intents"""
        
        if action in ["lighting", "light", "lamp"]:
            brightness = params.get("brightness", 0.7)
            color = params.get("color", "warm")
            
            if self.actuators and self.actuators.led_strip:
                if color == "off":
                    await self.actuators.led_strip.turn_off()
                else:
                    await self.actuators.set_mood(color, brightness)
            
            return {"status": "ok", "action": "lighting_adjusted"}
        
        elif action in ["mood", "sfeer", "ambiance"]:
            mood = params.get("mood", "relaxed")
            
            if self.actuators:
                await self.actuators.set_mood(mood)
            
            return {"status": "ok", "mood": mood}
        
        elif action in ["temperature", "temp"]:
            # In a real setup, this would control a thermostat
            target = params.get("target", 21)
            return {"status": "ok", "target_temperature": target, "note": "simulated"}
        
        return {"status": "unknown_action", "action": action}
    
    async def _execute_query(self, action: str, params: Dict) -> Dict:
        """Execute query intents"""
        
        if action in ["status", "state"]:
            # Return current device status
            status = {
                "device": AppConfig.DEVICE_NAME,
                "location": AppConfig.DEVICE_LOCATION,
                "uptime": "running",
                "jis_connected": self.jis.ws is not None,
                "fira_relations": len(self.jis.fira.relations),
                "chain_events": len(self.jis.chain.events)
            }
            
            if self.sense:
                readings = self.sense.get_current_readings()
                status["sensors"] = {
                    sid: {
                        "type": r.sensor_type.value,
                        "value": r.value
                    } for sid, r in readings.items()
                }
            
            return {"status": "ok", "data": status}
        
        elif action in ["sensors", "readings"]:
            if self.sense:
                readings = self.sense.get_current_readings()
                return {
                    "status": "ok",
                    "readings": {
                        sid: {
                            "type": r.sensor_type.value,
                            "value": r.value,
                            "timestamp": r.timestamp
                        } for sid, r in readings.items()
                    }
                }
            return {"status": "error", "message": "Sense not enabled"}
        
        elif action in ["calendar", "agenda"]:
            # Would integrate with calendar service
            return {"status": "ok", "message": "Calendar integration pending"}
        
        return {"status": "unknown_action", "action": action}
    
    async def _execute_emergency(self, action: str, params: Dict) -> Dict:
        """Execute emergency intents"""
        
        emergency_type = params.get("type", "generic")
        
        print(f"[EMERGENCY] Type: {emergency_type}, Action: {action}")
        
        if self.actuators:
            # Flash lights and sound alarm
            await self.actuators.alert("emergency")
        
        # Log to chain with high priority
        await self.jis.chain.append(
            event_type="emergency",
            result="triggered",
            extra_data={"type": emergency_type, "action": action}
        )
        
        return {"status": "emergency_triggered", "type": emergency_type}
    
    async def _execute_system(self, action: str, params: Dict) -> Dict:
        """Execute system intents"""
        
        if action == "identify":
            # Flash to identify this device
            if self.actuators and self.actuators.led_strip:
                await self.actuators.led_strip.blink(
                    StatusColor.CYAN.value, 
                    times=5
                )
            return {"status": "ok", "did": self.jis.identity.did}
        
        elif action == "restart":
            # Would restart services
            return {"status": "ok", "message": "Restart requested"}
        
        elif action == "status":
            return await self._execute_query("status", {})
        
        return {"status": "unknown_action", "action": action}
    
    # -------------------------------------------------------------------------
    # Sense Trigger Handler
    # -------------------------------------------------------------------------
    
    async def _handle_sense_trigger(self, action: str, params: Dict, context: Dict):
        """Handle triggers from sense engine"""
        
        print(f"[SENSE] Trigger: {action}")
        
        if action == "emergency":
            await self._execute_emergency("alert", params)
            
            # Notify via JIS
            if self.jis.ws:
                await self.jis.send_intent(
                    target_did="brein",
                    category="emergency",
                    action="sensor_alert",
                    params={
                        "source": AppConfig.DEVICE_NAME,
                        "type": params.get("type"),
                        "readings": context.get("readings", {})
                    }
                )
        
        elif action == "comfort":
            await self._execute_comfort(params.get("action", "adjust"), params)
        
        elif action == "system":
            # Log the event
            await self.jis.chain.append(
                event_type="sense_trigger",
                result="logged",
                extra_data={"action": action, "params": params}
            )
    
    # -------------------------------------------------------------------------
    # Main Loop
    # -------------------------------------------------------------------------
    
    async def run(self):
        """Run the application"""
        self._running = True
        
        print("[APP] Starting main loop...")
        print("[APP] Press Ctrl+C to exit")
        print()
        
        # Start background tasks
        tasks = []
        
        # JIS WebSocket connection
        tasks.append(asyncio.create_task(
            self.jis.connect_websocket()
        ))
        
        # Sense engine
        if self.sense:
            tasks.append(asyncio.create_task(
                self.sense.start()
            ))
        
        # Interactive console (for demo)
        tasks.append(asyncio.create_task(
            self._interactive_console()
        ))
        
        self._tasks = tasks
        
        try:
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            pass
    
    async def _interactive_console(self):
        """Interactive console for demo"""
        
        print("-" * 40)
        print("Interactive Console")
        print("-" * 40)
        print("Commands:")
        print("  /status    - Show device status")
        print("  /mood X    - Set mood (relaxed, energetic, etc)")
        print("  /light X   - Set brightness (0-100)")
        print("  /emergency - Trigger emergency demo")
        print("  /smoke     - Trigger smoke sensor demo")
        print("  /identify  - Flash to identify")
        print("  /quit      - Exit")
        print()
        print("Or just type naturally to talk to the LLM assistant.")
        print("-" * 40)
        print()
        
        loop = asyncio.get_event_loop()
        
        while self._running:
            try:
                # Read input asynchronously
                user_input = await loop.run_in_executor(
                    None, 
                    lambda: input("You: ").strip()
                )
                
                if not user_input:
                    continue
                
                # Handle commands
                if user_input.startswith("/"):
                    await self._handle_command(user_input)
                
                # Handle natural language
                elif self.llm:
                    result = await self.llm.process_text(user_input)
                    print(f"Kit: {result['response']}")
                    
                    if result['intent']['understood']:
                        print(f"     [Intent: {result['intent']['category']}"
                              f"/{result['intent']['action']}]")
                    print()
                
                else:
                    print("Kit: LLM niet beschikbaar. Gebruik /help voor commando's.")
                    print()
                    
            except EOFError:
                break
            except Exception as e:
                print(f"[ERROR] {e}")
    
    async def _handle_command(self, command: str):
        """Handle console commands"""
        
        parts = command[1:].split()
        cmd = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []
        
        if cmd == "quit" or cmd == "exit":
            self._running = False
            print("[APP] Shutting down...")
            for task in self._tasks:
                task.cancel()
        
        elif cmd == "status":
            result = await self._execute_query("status", {})
            print(json.dumps(result, indent=2, default=str))
        
        elif cmd == "mood":
            mood = args[0] if args else "relaxed"
            await self._execute_comfort("mood", {"mood": mood})
            print(f"[OK] Mood set to: {mood}")
        
        elif cmd == "light":
            brightness = int(args[0]) / 100 if args else 0.7
            await self._execute_comfort("lighting", {"brightness": brightness})
            print(f"[OK] Brightness set to: {int(brightness * 100)}%")
        
        elif cmd == "emergency":
            await self._execute_emergency("demo", {"type": "test"})
            print("[OK] Emergency demo triggered")
        
        elif cmd == "smoke":
            if self.sense:
                smoke_sensor = self.sense.sensors.get("smoke_kitchen")
                if smoke_sensor:
                    smoke_sensor.trigger()
                    print("[OK] Smoke sensor triggered - waiting for sense engine...")
                    await asyncio.sleep(2)
                    smoke_sensor.reset()
            else:
                print("[ERROR] Sense engine not enabled")
        
        elif cmd == "identify":
            await self._execute_system("identify", {})
            print(f"[OK] Device: {self.jis.identity.did}")
        
        elif cmd == "help":
            print("Commands: /status /mood /light /emergency /smoke /identify /quit")
        
        else:
            print(f"[ERROR] Unknown command: {cmd}")
        
        print()
    
    # -------------------------------------------------------------------------
    # Shutdown
    # -------------------------------------------------------------------------
    
    async def shutdown(self):
        """Clean shutdown"""
        print("\n[APP] Shutting down...")
        
        self._running = False
        
        # Cancel tasks
        for task in self._tasks:
            task.cancel()
        
        # Shutdown components
        if self.jis:
            await self.jis.shutdown()
        
        if self.sense:
            self.sense.stop()
        
        if self.llm:
            await self.llm.close()
        
        if self.actuators:
            if self.actuators.led_strip:
                await self.actuators.led_strip.turn_off()
        
        print("[APP] Goodbye!")


# =============================================================================
# Entry Point
# =============================================================================

async def main():
    """Main entry point"""
    
    app = JTelPiApp()
    
    # Handle signals
    loop = asyncio.get_event_loop()
    
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(
            sig,
            lambda: asyncio.create_task(app.shutdown())
        )
    
    try:
        await app.initialize()
        await app.run()
    except KeyboardInterrupt:
        pass
    finally:
        await app.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
