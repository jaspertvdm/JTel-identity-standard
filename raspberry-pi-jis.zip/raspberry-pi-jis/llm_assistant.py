"""
LLM Module for Raspberry Pi
============================

Integrates local LLM (via Ollama) for:
- Natural language intent parsing
- Contextual responses
- Conversational interface

Author: Jasper van de Meent / JTel
"""

import asyncio
import json
import aiohttp
from datetime import datetime
from dataclasses import dataclass
from typing import Optional, Dict, List, Any


# =============================================================================
# Configuration
# =============================================================================

class LLMConfig:
    """LLM Configuration"""
    
    # Ollama settings
    OLLAMA_URL = "http://localhost:11434"
    MODEL = "phi"  # Or "mistral:7b-instruct-q4_0" for more capability
    
    # Generation settings
    MAX_TOKENS = 256
    TEMPERATURE = 0.7
    
    # System prompt
    SYSTEM_PROMPT = """Je bent Kit, een slimme assistent voor het JTel systeem.

Je rol:
- Help de gebruiker met dagelijkse taken
- Geef korte, directe antwoorden
- Als je iets niet weet, zeg dat eerlijk
- Je spreekt Nederlands tenzij anders gevraagd

Context die je hebt:
- Je draait op een Raspberry Pi in huis
- Je bent verbonden met het Brein (centrale server)
- Je kunt apparaten aansturen via intents
- Je kent de gebruiker via FIR/A relaties

Belangrijke regels:
- Geef NOOIT informatie vrij over andere gebruikers
- Voer NOOIT acties uit zonder verificatie
- Bij twijfel, vraag om bevestiging
- Houd antwoorden kort en bondig"""


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class ParsedIntent:
    """Result of parsing natural language to intent"""
    understood: bool
    category: Optional[str]
    action: Optional[str]
    params: Dict[str, Any]
    confidence: float
    clarification_needed: Optional[str] = None


@dataclass
class ConversationTurn:
    """A single turn in conversation"""
    role: str  # "user" or "assistant"
    content: str
    timestamp: str


# =============================================================================
# Ollama Client
# =============================================================================

class OllamaClient:
    """Client for local Ollama LLM"""
    
    def __init__(self, base_url: str = None, model: str = None):
        self.base_url = base_url or LLMConfig.OLLAMA_URL
        self.model = model or LLMConfig.MODEL
        self.session: Optional[aiohttp.ClientSession] = None
        self.available = False
    
    async def initialize(self):
        """Initialize the client and check availability"""
        self.session = aiohttp.ClientSession()
        
        try:
            async with self.session.get(f"{self.base_url}/api/tags") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    models = [m["name"] for m in data.get("models", [])]
                    
                    if any(self.model in m for m in models):
                        self.available = True
                        print(f"[LLM] Ollama available with model: {self.model}")
                    else:
                        print(f"[LLM] Model {self.model} not found. Available: {models}")
                        print(f"[LLM] Run: ollama pull {self.model}")
        except Exception as e:
            print(f"[LLM] Ollama not available: {e}")
            print("[LLM] Make sure Ollama is running: ollama serve")
    
    async def generate(
        self,
        prompt: str,
        system: str = None,
        context: List[int] = None,
        max_tokens: int = None,
        temperature: float = None
    ) -> Optional[str]:
        """Generate a response"""
        
        if not self.available:
            return None
        
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_predict": max_tokens or LLMConfig.MAX_TOKENS,
                    "temperature": temperature or LLMConfig.TEMPERATURE
                }
            }
            
            if system:
                payload["system"] = system
            
            if context:
                payload["context"] = context
            
            async with self.session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("response", "").strip()
                else:
                    print(f"[LLM] Generate error: {resp.status}")
                    return None
                    
        except Exception as e:
            print(f"[LLM] Generate error: {e}")
            return None
    
    async def chat(
        self,
        messages: List[Dict[str, str]],
        system: str = None
    ) -> Optional[str]:
        """Chat-style generation with message history"""
        
        if not self.available:
            return None
        
        try:
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": False
            }
            
            if system:
                # Prepend system message
                payload["messages"] = [{"role": "system", "content": system}] + messages
            
            async with self.session.post(
                f"{self.base_url}/api/chat",
                json=payload
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("message", {}).get("content", "").strip()
                else:
                    print(f"[LLM] Chat error: {resp.status}")
                    return None
                    
        except Exception as e:
            print(f"[LLM] Chat error: {e}")
            return None
    
    async def close(self):
        """Close the client"""
        if self.session:
            await self.session.close()


# =============================================================================
# Intent Parser
# =============================================================================

class IntentParser:
    """Parses natural language into structured intents"""
    
    PARSE_PROMPT = """Analyseer de volgende gebruikersinput en bepaal de intent.

Mogelijke categorieën:
- comfort: verlichting, temperatuur, muziek, sfeer
- query: vragen over agenda, weer, informatie
- communication: bellen, berichten, contacten
- security: deuren, camera's, alarm
- system: instellingen, status, help
- emergency: noodgevallen, alarm

Geef je antwoord ALLEEN als JSON in dit format:
{
  "understood": true/false,
  "category": "categorie",
  "action": "specifieke actie",
  "params": {"param1": "waarde1"},
  "confidence": 0.0-1.0,
  "clarification": "vraag indien nodig"
}

Gebruikersinput: """
    
    def __init__(self, llm: OllamaClient):
        self.llm = llm
    
    async def parse(self, user_input: str, context: Dict = None) -> ParsedIntent:
        """Parse user input to intent"""
        
        # Build prompt with context
        prompt = self.PARSE_PROMPT + f'"{user_input}"'
        
        if context:
            prompt += f"\n\nContext: {json.dumps(context)}"
        
        response = await self.llm.generate(
            prompt=prompt,
            temperature=0.3  # Lower temperature for more consistent parsing
        )
        
        if not response:
            return ParsedIntent(
                understood=False,
                category=None,
                action=None,
                params={},
                confidence=0.0,
                clarification_needed="Ik kon je niet verstaan. Kun je dat herhalen?"
            )
        
        # Try to parse JSON from response
        try:
            # Find JSON in response
            start = response.find("{")
            end = response.rfind("}") + 1
            if start >= 0 and end > start:
                json_str = response[start:end]
                data = json.loads(json_str)
                
                return ParsedIntent(
                    understood=data.get("understood", False),
                    category=data.get("category"),
                    action=data.get("action"),
                    params=data.get("params", {}),
                    confidence=data.get("confidence", 0.5),
                    clarification_needed=data.get("clarification")
                )
        except json.JSONDecodeError:
            pass
        
        # Fallback: try simple keyword matching
        return self._keyword_fallback(user_input)
    
    def _keyword_fallback(self, user_input: str) -> ParsedIntent:
        """Simple keyword-based intent detection as fallback"""
        
        lower = user_input.lower()
        
        # Comfort
        if any(w in lower for w in ["licht", "lamp", "donker", "helder"]):
            return ParsedIntent(True, "comfort", "lighting", {}, 0.6)
        
        if any(w in lower for w in ["warm", "koud", "temperatuur", "graden"]):
            return ParsedIntent(True, "comfort", "temperature", {}, 0.6)
        
        if any(w in lower for w in ["muziek", "spotify", "stil", "geluid"]):
            return ParsedIntent(True, "comfort", "audio", {}, 0.6)
        
        # Query
        if any(w in lower for w in ["agenda", "afspraak", "planning", "wanneer"]):
            return ParsedIntent(True, "query", "calendar", {}, 0.6)
        
        if any(w in lower for w in ["weer", "temperatuur buiten", "regent"]):
            return ParsedIntent(True, "query", "weather", {}, 0.6)
        
        # Communication
        if any(w in lower for w in ["bel", "bellen", "telefoneer"]):
            return ParsedIntent(True, "communication", "call", {}, 0.6)
        
        if any(w in lower for w in ["bericht", "stuur", "app", "sms"]):
            return ParsedIntent(True, "communication", "message", {}, 0.6)
        
        # Security
        if any(w in lower for w in ["deur", "slot", "open", "dicht"]):
            return ParsedIntent(True, "security", "door", {}, 0.6)
        
        # Emergency
        if any(w in lower for w in ["help", "nood", "alarm", "brand"]):
            return ParsedIntent(True, "emergency", "alert", {}, 0.8)
        
        # Unknown
        return ParsedIntent(
            understood=False,
            category=None,
            action=None,
            params={},
            confidence=0.0,
            clarification_needed="Ik begrijp niet helemaal wat je bedoelt. Kun je het anders formuleren?"
        )


# =============================================================================
# Conversation Manager
# =============================================================================

class ConversationManager:
    """Manages conversation state and generates responses"""
    
    def __init__(self, llm: OllamaClient):
        self.llm = llm
        self.parser = IntentParser(llm)
        self.history: List[ConversationTurn] = []
        self.max_history = 10
        self.context: Dict = {}
    
    def set_context(self, key: str, value: Any):
        """Set conversation context"""
        self.context[key] = value
    
    def clear_history(self):
        """Clear conversation history"""
        self.history = []
    
    async def process(self, user_input: str) -> Dict:
        """Process user input and generate response"""
        
        # Add to history
        self.history.append(ConversationTurn(
            role="user",
            content=user_input,
            timestamp=datetime.utcnow().isoformat()
        ))
        
        # Parse intent
        intent = await self.parser.parse(user_input, self.context)
        
        # Generate response based on intent
        if intent.understood and intent.confidence > 0.5:
            response = await self._generate_response(user_input, intent)
        else:
            response = intent.clarification_needed or "Kun je dat herhalen?"
        
        # Add response to history
        self.history.append(ConversationTurn(
            role="assistant",
            content=response,
            timestamp=datetime.utcnow().isoformat()
        ))
        
        # Trim history
        if len(self.history) > self.max_history * 2:
            self.history = self.history[-self.max_history * 2:]
        
        return {
            "response": response,
            "intent": {
                "understood": intent.understood,
                "category": intent.category,
                "action": intent.action,
                "params": intent.params,
                "confidence": intent.confidence
            }
        }
    
    async def _generate_response(self, user_input: str, intent: ParsedIntent) -> str:
        """Generate a contextual response"""
        
        # Build messages for chat
        messages = []
        
        for turn in self.history[-6:]:  # Last 3 exchanges
            messages.append({
                "role": turn.role,
                "content": turn.content
            })
        
        # Add context to system prompt
        system = LLMConfig.SYSTEM_PROMPT
        if self.context:
            system += f"\n\nHuidige context:\n{json.dumps(self.context, indent=2, ensure_ascii=False)}"
        
        system += f"\n\nGedetecteerde intent: {intent.category}/{intent.action}"
        
        # Generate response
        response = await self.llm.chat(messages, system)
        
        if response:
            return response
        
        # Fallback responses
        fallbacks = {
            "comfort": "Ik pas de instellingen aan.",
            "query": "Ik zoek dat voor je op.",
            "communication": "Ik regel de verbinding.",
            "security": "Ik controleer de beveiliging.",
            "system": "Ik bekijk de systeemstatus.",
            "emergency": "Ik stuur direct een noodmelding!"
        }
        
        return fallbacks.get(intent.category, "Ik help je daar graag mee.")


# =============================================================================
# Voice Interface (TTS/STT stubs)
# =============================================================================

class VoiceInterface:
    """Voice interface for speech-to-text and text-to-speech"""
    
    def __init__(self):
        self.tts_available = False
        self.stt_available = False
        self._init_tts()
        self._init_stt()
    
    def _init_tts(self):
        """Initialize text-to-speech"""
        try:
            import pyttsx3
            self.tts_engine = pyttsx3.init()
            self.tts_engine.setProperty('rate', 150)
            self.tts_available = True
            print("[VOICE] TTS initialized")
        except:
            print("[VOICE] TTS not available")
    
    def _init_stt(self):
        """Initialize speech-to-text"""
        try:
            import speech_recognition as sr
            self.recognizer = sr.Recognizer()
            self.microphone = sr.Microphone()
            self.stt_available = True
            print("[VOICE] STT initialized")
        except:
            print("[VOICE] STT not available")
    
    async def speak(self, text: str):
        """Convert text to speech"""
        if self.tts_available:
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
        else:
            print(f"[VOICE] Would say: {text}")
    
    async def listen(self, timeout: float = 5.0) -> Optional[str]:
        """Listen for speech and convert to text"""
        if not self.stt_available:
            return None
        
        import speech_recognition as sr
        
        try:
            with self.microphone as source:
                print("[VOICE] Listening...")
                audio = self.recognizer.listen(source, timeout=timeout)
            
            text = self.recognizer.recognize_google(audio, language="nl-NL")
            print(f"[VOICE] Heard: {text}")
            return text
            
        except sr.WaitTimeoutError:
            print("[VOICE] No speech detected")
        except sr.UnknownValueError:
            print("[VOICE] Could not understand audio")
        except sr.RequestError as e:
            print(f"[VOICE] STT error: {e}")
        
        return None


# =============================================================================
# Main LLM Assistant
# =============================================================================

class LLMAssistant:
    """Main LLM assistant combining all components"""
    
    def __init__(self):
        self.llm = OllamaClient()
        self.conversation: Optional[ConversationManager] = None
        self.voice = VoiceInterface()
        
        self.intent_callbacks: Dict[str, callable] = {}
    
    async def initialize(self):
        """Initialize the assistant"""
        await self.llm.initialize()
        self.conversation = ConversationManager(self.llm)
        print("[LLM] Assistant initialized")
    
    def set_context(self, key: str, value: Any):
        """Set context for the conversation"""
        if self.conversation:
            self.conversation.set_context(key, value)
    
    def on_intent(self, category: str, callback: callable):
        """Register callback for specific intent category"""
        self.intent_callbacks[category] = callback
    
    async def process_text(self, text: str) -> Dict:
        """Process text input"""
        if not self.conversation:
            return {"response": "Assistant niet beschikbaar", "intent": None}
        
        result = await self.conversation.process(text)
        
        # Call intent callback if registered
        intent = result.get("intent", {})
        if intent.get("understood") and intent.get("category"):
            callback = self.intent_callbacks.get(intent["category"])
            if callback:
                await callback(intent)
        
        return result
    
    async def process_voice(self) -> Optional[Dict]:
        """Process voice input"""
        text = await self.voice.listen()
        if text:
            result = await self.process_text(text)
            await self.voice.speak(result["response"])
            return result
        return None
    
    async def speak(self, text: str):
        """Speak text"""
        await self.voice.speak(text)
    
    async def close(self):
        """Close the assistant"""
        await self.llm.close()


# =============================================================================
# CLI for Testing
# =============================================================================

async def main():
    """Test the LLM assistant"""
    assistant = LLMAssistant()
    await assistant.initialize()
    
    # Set some context
    assistant.set_context("user_name", "Jasper")
    assistant.set_context("location", "Woonkamer")
    assistant.set_context("time_of_day", "avond")
    
    # Register intent callback
    @assistant.on_intent("comfort")
    async def handle_comfort(intent):
        print(f"[CALLBACK] Comfort intent: {intent}")
    
    print("\n[LLM] Assistant ready. Type 'quit' to exit.\n")
    
    while True:
        try:
            user_input = input("Jij: ").strip()
            
            if user_input.lower() in ["quit", "exit", "stop"]:
                break
            
            if not user_input:
                continue
            
            result = await assistant.process_text(user_input)
            print(f"Kit: {result['response']}")
            
            if result['intent']['understood']:
                print(f"     [Intent: {result['intent']['category']}/{result['intent']['action']} "
                      f"({result['intent']['confidence']:.0%})]")
            print()
            
        except KeyboardInterrupt:
            break
    
    await assistant.close()
    print("\n[LLM] Goodbye!")


if __name__ == "__main__":
    asyncio.run(main())
