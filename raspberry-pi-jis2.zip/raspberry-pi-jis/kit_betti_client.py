"""
Kit BETTI Client
=================

Client-side TBET functionality for the Kit app.
Enables users to:
- Request registered contact
- Respond to TBET requests
- View pending/upcoming TBETs
- Execute registered communication

This integrates with the main Kit app UI.

Author: Jasper van de Meent / JTel
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Callable, Any
from dataclasses import dataclass
from enum import Enum

# Would import from betti.py in production
# from betti import IntentClassification, TBETType, TBETStatus


# =============================================================================
# Enums (duplicated for standalone use, would import in production)
# =============================================================================

class IntentClassification(Enum):
    CASUAL = "casual"
    BUSINESS = "business"
    FORMAL = "formal"
    LEGAL = "legal"
    GOVERNMENT = "government"
    EMERGENCY = "emergency"


class TBETType(Enum):
    CALL = "call"
    MESSAGE = "message"
    DOCUMENT = "document"
    MEETING = "meeting"
    SIGNATURE = "signature"
    VERIFICATION = "verification"
    TRANSACTION = "transaction"


class TBETStatus(Enum):
    DRAFT = "draft"
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    COUNTERED = "countered"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    DISPUTED = "disputed"


# =============================================================================
# Data Classes for UI
# =============================================================================

@dataclass
class TBETSummary:
    """Summary of a TBET for UI display"""
    tbet_id: str
    other_party_did: str
    other_party_name: str  # Resolved from DID
    subject: str
    classification: str
    tbet_type: str
    status: str
    time: datetime
    is_initiator: bool
    requires_action: bool


@dataclass
class TBETNotification:
    """Notification about a TBET event"""
    notification_id: str
    tbet_id: str
    event_type: str  # "request", "accepted", "rejected", "reminder", "starting"
    title: str
    body: str
    timestamp: datetime
    action_required: bool
    actions: List[str]  # ["accept", "reject", "counter", "view"]


# =============================================================================
# Kit BETTI Client
# =============================================================================

class KitBETTIClient:
    """
    Client for BETTI operations in the Kit app.
    Communicates with Brein backend for TBET management.
    """
    
    def __init__(self, jis_client=None):
        self.jis_client = jis_client
        self.my_did: str = None
        self.brein_url: str = "http://192.168.4.76:8081"
        
        # Callbacks
        self.on_notification: Callable[[TBETNotification], None] = None
        self.on_tbet_update: Callable[[str, str], None] = None  # tbet_id, new_status
        
        # Cache
        self.pending_tbets: List[TBETSummary] = []
        self.upcoming_tbets: List[TBETSummary] = []
        
        # HTTP session
        self.session = None
    
    async def initialize(self, my_did: str, session=None):
        """Initialize the client"""
        self.my_did = my_did
        self.session = session
        
        if not self.session:
            import aiohttp
            self.session = aiohttp.ClientSession()
        
        # Load initial data
        await self.refresh_pending()
        await self.refresh_upcoming()
        
        print(f"[KIT-BETTI] Initialized for {my_did}")
        print(f"[KIT-BETTI] Pending: {len(self.pending_tbets)}, Upcoming: {len(self.upcoming_tbets)}")
    
    # -------------------------------------------------------------------------
    # Creating TBETs (Initiating registered contact)
    # -------------------------------------------------------------------------
    
    async def request_registered_call(
        self,
        recipient_did: str,
        subject: str,
        description: str = "",
        proposed_time: datetime = None,
        duration_minutes: int = 30,
        classification: IntentClassification = IntentClassification.FORMAL
    ) -> Dict:
        """
        Request a registered call.
        This is "aangetekend bellen".
        """
        return await self._create_tbet(
            recipient_did=recipient_did,
            tbet_type=TBETType.CALL,
            subject=subject,
            description=description,
            proposed_time=proposed_time or datetime.now() + timedelta(hours=1),
            duration_minutes=duration_minutes,
            classification=classification
        )
    
    async def send_registered_message(
        self,
        recipient_did: str,
        subject: str,
        message: str,
        attachments: List[str] = None,
        classification: IntentClassification = IntentClassification.FORMAL
    ) -> Dict:
        """
        Send a registered message.
        This is "aangetekend mailen/appen".
        """
        return await self._create_tbet(
            recipient_did=recipient_did,
            tbet_type=TBETType.MESSAGE,
            subject=subject,
            description=message,
            proposed_time=datetime.now() + timedelta(minutes=5),  # Near-immediate
            duration_minutes=5,
            classification=classification,
            metadata={"attachments": attachments or []}
        )
    
    async def request_document_signing(
        self,
        recipient_did: str,
        document_name: str,
        document_hash: str,
        proposed_time: datetime,
        classification: IntentClassification = IntentClassification.LEGAL
    ) -> Dict:
        """
        Request a document signing session.
        """
        return await self._create_tbet(
            recipient_did=recipient_did,
            tbet_type=TBETType.SIGNATURE,
            subject=f"Ondertekening: {document_name}",
            description=f"Document hash: {document_hash}",
            proposed_time=proposed_time,
            duration_minutes=30,
            classification=classification,
            metadata={"document_hash": document_hash}
        )
    
    async def request_verification(
        self,
        recipient_did: str,
        verification_type: str,  # "identity", "credential", "document"
        purpose: str,
        valid_until: datetime = None
    ) -> Dict:
        """
        Request verification of identity/credential.
        Used for things like temporary rijbewijs verificatie.
        """
        return await self._create_tbet(
            recipient_did=recipient_did,
            tbet_type=TBETType.VERIFICATION,
            subject=f"Verificatie aanvraag: {verification_type}",
            description=purpose,
            proposed_time=datetime.now() + timedelta(minutes=5),
            duration_minutes=10,
            classification=IntentClassification.FORMAL,
            metadata={
                "verification_type": verification_type,
                "valid_until": valid_until.isoformat() if valid_until else None
            }
        )
    
    async def _create_tbet(
        self,
        recipient_did: str,
        tbet_type: TBETType,
        subject: str,
        description: str,
        proposed_time: datetime,
        duration_minutes: int,
        classification: IntentClassification,
        metadata: Dict = None
    ) -> Dict:
        """Create and submit a TBET"""
        
        payload = {
            "initiator_did": self.my_did,
            "recipient_did": recipient_did,
            "tbet_type": tbet_type.value,
            "classification": classification.value,
            "subject": subject,
            "description": description,
            "proposed_start": proposed_time.isoformat(),
            "duration_minutes": duration_minutes,
            "metadata": metadata or {}
        }
        
        try:
            async with self.session.post(
                f"{self.brein_url}/betti/tbet",
                json=payload
            ) as resp:
                result = await resp.json()
                
                if result.get("success"):
                    print(f"[KIT-BETTI] TBET created: {result['tbet_id']}")
                    
                    # Log to chain
                    if self.jis_client:
                        await self.jis_client.chain.append(
                            event_type="tbet_created",
                            remote_did=recipient_did,
                            intent=f"registered/{tbet_type.value}",
                            result="pending",
                            extra_data={"tbet_id": result["tbet_id"]}
                        )
                
                return result
                
        except Exception as e:
            print(f"[KIT-BETTI] Create error: {e}")
            return {"success": False, "error": str(e)}
    
    # -------------------------------------------------------------------------
    # Responding to TBETs
    # -------------------------------------------------------------------------
    
    async def accept_tbet(self, tbet_id: str) -> Dict:
        """Accept a TBET request"""
        return await self._respond_tbet(tbet_id, "accept")
    
    async def reject_tbet(self, tbet_id: str, reason: str = None) -> Dict:
        """Reject a TBET request"""
        return await self._respond_tbet(tbet_id, "reject", reason=reason)
    
    async def counter_tbet(self, tbet_id: str, new_time: datetime) -> Dict:
        """Counter-propose a different time"""
        return await self._respond_tbet(tbet_id, "counter", counter_time=new_time)
    
    async def _respond_tbet(
        self,
        tbet_id: str,
        action: str,
        reason: str = None,
        counter_time: datetime = None
    ) -> Dict:
        """Respond to a TBET"""
        
        payload = {
            "tbet_id": tbet_id,
            "responder_did": self.my_did,
            "action": action,
            "reason": reason,
            "counter_time": counter_time.isoformat() if counter_time else None
        }
        
        try:
            async with self.session.post(
                f"{self.brein_url}/betti/tbet/{tbet_id}/respond",
                json=payload
            ) as resp:
                result = await resp.json()
                
                if result.get("success"):
                    print(f"[KIT-BETTI] TBET {action}ed: {tbet_id}")
                    await self.refresh_pending()
                    await self.refresh_upcoming()
                
                return result
                
        except Exception as e:
            print(f"[KIT-BETTI] Respond error: {e}")
            return {"success": False, "error": str(e)}
    
    # -------------------------------------------------------------------------
    # Executing TBETs
    # -------------------------------------------------------------------------
    
    async def start_registered_communication(self, tbet_id: str) -> Dict:
        """Start executing a TBET (begin the call/meeting/etc)"""
        
        try:
            async with self.session.post(
                f"{self.brein_url}/betti/tbet/{tbet_id}/execute",
                json={"tbet_id": tbet_id, "action": "start"}
            ) as resp:
                result = await resp.json()
                
                if result.get("success"):
                    print(f"[KIT-BETTI] Execution started: {tbet_id}")
                
                return result
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def complete_registered_communication(
        self,
        tbet_id: str,
        outcome: str = "completed",
        notes: str = None
    ) -> Dict:
        """Complete a TBET execution"""
        
        try:
            async with self.session.post(
                f"{self.brein_url}/betti/tbet/{tbet_id}/execute",
                json={
                    "tbet_id": tbet_id,
                    "action": "complete",
                    "outcome": outcome,
                    "notes": notes
                }
            ) as resp:
                result = await resp.json()
                
                if result.get("success"):
                    print(f"[KIT-BETTI] Execution completed: {tbet_id}")
                    print(f"[KIT-BETTI] Proof hash: {result.get('proof', {}).get('execution_hash')}")
                
                return result
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # -------------------------------------------------------------------------
    # Queries
    # -------------------------------------------------------------------------
    
    async def refresh_pending(self):
        """Refresh pending TBETs (inbox)"""
        try:
            async with self.session.get(
                f"{self.brein_url}/betti/pending/{self.my_did}"
            ) as resp:
                result = await resp.json()
                
                if result.get("success"):
                    self.pending_tbets = [
                        TBETSummary(
                            tbet_id=t["tbet_id"],
                            other_party_did=t["from"],
                            other_party_name=self._resolve_name(t["from"]),
                            subject=t["subject"],
                            classification=t["classification"],
                            tbet_type=t["type"],
                            status="pending",
                            time=datetime.fromisoformat(t["proposed_time"]),
                            is_initiator=False,
                            requires_action=True
                        )
                        for t in result.get("pending", [])
                    ]
                    
        except Exception as e:
            print(f"[KIT-BETTI] Refresh pending error: {e}")
    
    async def refresh_upcoming(self):
        """Refresh upcoming TBETs (calendar)"""
        try:
            async with self.session.get(
                f"{self.brein_url}/betti/upcoming/{self.my_did}"
            ) as resp:
                result = await resp.json()
                
                if result.get("success"):
                    self.upcoming_tbets = [
                        TBETSummary(
                            tbet_id=t["tbet_id"],
                            other_party_did=t["other_party"],
                            other_party_name=self._resolve_name(t["other_party"]),
                            subject=t["subject"],
                            classification=t["classification"],
                            tbet_type=t["type"],
                            status="accepted",
                            time=datetime.fromisoformat(t["confirmed_time"]),
                            is_initiator=True,  # Could be either
                            requires_action=False
                        )
                        for t in result.get("upcoming", [])
                    ]
                    
        except Exception as e:
            print(f"[KIT-BETTI] Refresh upcoming error: {e}")
    
    async def get_tbet_details(self, tbet_id: str) -> Optional[Dict]:
        """Get full TBET details"""
        try:
            async with self.session.get(
                f"{self.brein_url}/betti/tbet/{tbet_id}"
            ) as resp:
                result = await resp.json()
                if result.get("success"):
                    return result.get("tbet")
                return None
        except Exception as e:
            print(f"[KIT-BETTI] Get details error: {e}")
            return None
    
    async def check_availability(
        self,
        recipient_did: str,
        proposed_time: datetime,
        duration_minutes: int = 30
    ) -> Dict:
        """Check if a time slot is available for a recipient"""
        try:
            async with self.session.get(
                f"{self.brein_url}/betti/availability/{recipient_did}",
                params={
                    "start": proposed_time.isoformat(),
                    "duration_minutes": duration_minutes
                }
            ) as resp:
                return await resp.json()
        except Exception as e:
            return {"success": False, "available": False, "error": str(e)}
    
    # -------------------------------------------------------------------------
    # Notification Handling
    # -------------------------------------------------------------------------
    
    async def handle_notification(self, notification_data: Dict):
        """Handle incoming TBET notification"""
        
        event_type = notification_data.get("type")
        tbet_id = notification_data.get("tbet_id")
        
        # Create notification object
        notification = TBETNotification(
            notification_id=f"notif_{tbet_id}_{event_type}",
            tbet_id=tbet_id,
            event_type=event_type,
            title=self._get_notification_title(event_type, notification_data),
            body=self._get_notification_body(event_type, notification_data),
            timestamp=datetime.now(),
            action_required=event_type == "tbet_request",
            actions=self._get_notification_actions(event_type)
        )
        
        # Call handler if registered
        if self.on_notification:
            await self.on_notification(notification)
        
        # Refresh data
        await self.refresh_pending()
        await self.refresh_upcoming()
    
    def _get_notification_title(self, event_type: str, data: Dict) -> str:
        """Get notification title based on event type"""
        titles = {
            "tbet_request": "📩 Aangetekend verzoek",
            "tbet_accepted": "✅ Verzoek geaccepteerd",
            "tbet_rejected": "❌ Verzoek afgewezen",
            "tbet_countered": "🔄 Tegenvoorstel ontvangen",
            "tbet_reminder": "⏰ Herinnering",
            "tbet_starting": "🔔 Gesprek begint nu",
            "tbet_completed": "✓ Gesprek afgerond"
        }
        return titles.get(event_type, "TBET Update")
    
    def _get_notification_body(self, event_type: str, data: Dict) -> str:
        """Get notification body based on event type"""
        subject = data.get("subject", "")
        from_did = data.get("from", "")
        
        if event_type == "tbet_request":
            return f"Nieuw aangetekend verzoek van {self._resolve_name(from_did)}: {subject}"
        elif event_type == "tbet_accepted":
            return f"Je verzoek '{subject}' is geaccepteerd"
        elif event_type == "tbet_rejected":
            return f"Je verzoek '{subject}' is afgewezen"
        
        return subject
    
    def _get_notification_actions(self, event_type: str) -> List[str]:
        """Get available actions for a notification"""
        if event_type == "tbet_request":
            return ["accept", "reject", "counter", "view"]
        elif event_type in ["tbet_reminder", "tbet_starting"]:
            return ["join", "view"]
        return ["view"]
    
    def _resolve_name(self, did: str) -> str:
        """Resolve DID to human-readable name"""
        # In production, this would query a DID resolver
        # For now, extract from DID
        if ":" in did:
            parts = did.split(":")
            return parts[-1].replace("-", " ").title()
        return did
    
    # -------------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------------
    
    async def close(self):
        """Close the client"""
        if self.session:
            await self.session.close()


# =============================================================================
# UI Cards for Kit App
# =============================================================================

class TBETCard:
    """
    Generates card data for Kit app UI.
    Cards are the primary UI element in Kit.
    """
    
    @staticmethod
    def pending_request_card(tbet: TBETSummary) -> Dict:
        """Generate a card for a pending TBET request"""
        
        classification_icons = {
            "casual": "💬",
            "business": "💼",
            "formal": "📋",
            "legal": "⚖️",
            "government": "🏛️"
        }
        
        type_icons = {
            "call": "📞",
            "message": "✉️",
            "document": "📄",
            "meeting": "🤝",
            "signature": "✍️",
            "verification": "🔐"
        }
        
        return {
            "card_type": "tbet_request",
            "tbet_id": tbet.tbet_id,
            "title": f"{classification_icons.get(tbet.classification, '📩')} Aangetekend verzoek",
            "subtitle": tbet.other_party_name,
            "body": tbet.subject,
            "time": tbet.time.strftime("%d %b %H:%M"),
            "icon": type_icons.get(tbet.tbet_type, "📩"),
            "classification_badge": tbet.classification.upper(),
            "actions": [
                {"id": "accept", "label": "Accepteer", "style": "primary"},
                {"id": "reject", "label": "Weiger", "style": "secondary"},
                {"id": "counter", "label": "Ander tijdstip", "style": "text"}
            ],
            "priority": "high" if tbet.classification in ["legal", "government"] else "normal"
        }
    
    @staticmethod
    def upcoming_card(tbet: TBETSummary) -> Dict:
        """Generate a card for an upcoming TBET"""
        
        time_until = tbet.time - datetime.now()
        
        if time_until.total_seconds() < 3600:
            time_text = f"Over {int(time_until.total_seconds() / 60)} minuten"
        elif time_until.total_seconds() < 86400:
            time_text = f"Vandaag om {tbet.time.strftime('%H:%M')}"
        else:
            time_text = tbet.time.strftime("%d %b %H:%M")
        
        return {
            "card_type": "tbet_upcoming",
            "tbet_id": tbet.tbet_id,
            "title": tbet.subject,
            "subtitle": f"Met {tbet.other_party_name}",
            "time": time_text,
            "classification_badge": tbet.classification.upper(),
            "type_badge": tbet.tbet_type.upper(),
            "actions": [
                {"id": "join", "label": "Start", "style": "primary"},
                {"id": "reschedule", "label": "Verzet", "style": "text"},
                {"id": "cancel", "label": "Annuleer", "style": "danger"}
            ]
        }
    
    @staticmethod
    def execution_card(tbet_id: str, subject: str, other_party: str, duration: int) -> Dict:
        """Generate a card for active TBET execution"""
        return {
            "card_type": "tbet_executing",
            "tbet_id": tbet_id,
            "title": f"🔴 {subject}",
            "subtitle": f"Aangetekend gesprek met {other_party}",
            "timer": duration,  # Seconds elapsed
            "actions": [
                {"id": "end", "label": "Beëindig gesprek", "style": "danger"},
                {"id": "note", "label": "Notitie", "style": "text"}
            ],
            "indicators": [
                {"icon": "🔒", "text": "Beveiligd"},
                {"icon": "📝", "text": "Wordt vastgelegd"}
            ]
        }
    
    @staticmethod
    def proof_card(tbet_id: str, proof: Dict) -> Dict:
        """Generate a card showing TBET proof after completion"""
        return {
            "card_type": "tbet_proof",
            "tbet_id": tbet_id,
            "title": "✓ Aangetekend gesprek afgerond",
            "details": [
                {"label": "Gestart", "value": proof.get("started_at", "")},
                {"label": "Beëindigd", "value": proof.get("ended_at", "")},
                {"label": "Duur", "value": f"{proof.get('duration_seconds', 0) // 60} minuten"},
                {"label": "Bewijs hash", "value": proof.get("execution_hash", "")[:16] + "..."}
            ],
            "actions": [
                {"id": "download_proof", "label": "Download bewijs", "style": "primary"},
                {"id": "share", "label": "Deel", "style": "text"}
            ]
        }


# =============================================================================
# CLI Test
# =============================================================================

async def main():
    """Test the Kit BETTI client"""
    
    print("=" * 60)
    print("Kit BETTI Client Test")
    print("=" * 60)
    
    # Note: This requires the Brein server to be running
    # For standalone testing, we'll simulate
    
    client = KitBETTIClient()
    
    # Simulate initialization
    client.my_did = "did:jtel:user:jasper"
    
    print(f"\nClient initialized for: {client.my_did}")
    
    # Show card examples
    print("\n" + "-" * 40)
    print("Example Cards:")
    print("-" * 40)
    
    # Pending request card
    pending = TBETSummary(
        tbet_id="test-123",
        other_party_did="did:jtel:org:belastingdienst",
        other_party_name="Belastingdienst",
        subject="Aangetekend: Reactie op bezwaarschrift",
        classification="government",
        tbet_type="call",
        status="pending",
        time=datetime.now() + timedelta(hours=2),
        is_initiator=False,
        requires_action=True
    )
    
    card = TBETCard.pending_request_card(pending)
    print("\nPending Request Card:")
    print(json.dumps(card, indent=2, default=str))
    
    # Upcoming card
    upcoming = TBETSummary(
        tbet_id="test-456",
        other_party_did="did:jtel:user:advocaat",
        other_party_name="Mr. De Vries",
        subject="Koopakte bespreking",
        classification="legal",
        tbet_type="meeting",
        status="accepted",
        time=datetime.now() + timedelta(minutes=30),
        is_initiator=True,
        requires_action=False
    )
    
    card = TBETCard.upcoming_card(upcoming)
    print("\nUpcoming Card:")
    print(json.dumps(card, indent=2, default=str))
    
    # Execution card
    card = TBETCard.execution_card(
        "test-789",
        "Bezwaar WOZ-waarde",
        "Gemeente Zeist",
        duration=345
    )
    print("\nExecution Card:")
    print(json.dumps(card, indent=2, default=str))
    
    # Proof card
    card = TBETCard.proof_card(
        "test-789",
        {
            "started_at": "2024-11-26T14:00:00",
            "ended_at": "2024-11-26T14:23:45",
            "duration_seconds": 1425,
            "execution_hash": "a3f8c2d1e5b6a7c8d9e0f1a2b3c4d5e6f7a8b9c0"
        }
    )
    print("\nProof Card:")
    print(json.dumps(card, indent=2, default=str))
    
    print("\n" + "=" * 60)
    print("Test complete!")


if __name__ == "__main__":
    asyncio.run(main())
