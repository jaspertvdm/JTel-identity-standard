"""
Brein BETTI Endpoints
=====================

Server-side endpoints for TBET management.
Integrates with the Brein backend to provide:
- TBET creation and submission
- Recipient notification
- Acceptance/rejection handling
- Execution tracking
- Proof generation

This would integrate into your existing Brein Rust/Python backend.

Author: Jasper van de Meent / JTel
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from dataclasses import dataclass
import json
import hashlib
import uuid

# In production, these would be proper framework imports
# from fastapi import APIRouter, HTTPException, Depends
# from pydantic import BaseModel

from betti import (
    BETTIService, BETTIRegistry, TBETBuilder, TBET,
    IntentClassification, TBETType, TBETStatus, TimeSlot
)


# =============================================================================
# Request/Response Models (Pydantic-style for FastAPI)
# =============================================================================

@dataclass
class TBETCreateRequest:
    """Request to create a new TBET"""
    initiator_did: str
    recipient_did: str
    tbet_type: str  # "call", "message", "document", etc.
    classification: str  # "casual", "business", "formal", "legal"
    subject: str
    description: str
    proposed_start: str  # ISO datetime
    duration_minutes: int = 30
    witnesses: List[str] = None
    attachments: List[str] = None
    metadata: Dict[str, Any] = None


@dataclass
class TBETResponseRequest:
    """Request to respond to a TBET"""
    tbet_id: str
    responder_did: str
    action: str  # "accept", "reject", "counter"
    counter_time: Optional[str] = None  # ISO datetime for counter
    reason: Optional[str] = None
    signature: Optional[str] = None


@dataclass
class TBETExecutionRequest:
    """Request to start/end TBET execution"""
    tbet_id: str
    action: str  # "start", "complete", "fail"
    outcome: Optional[str] = None
    notes: Optional[str] = None
    execution_data: Optional[Dict] = None


@dataclass
class TBETQueryRequest:
    """Request to query TBETs"""
    did: str
    role: Optional[str] = None  # "initiator", "recipient", or None for both
    status: Optional[str] = None
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    limit: int = 50


# =============================================================================
# Brein BETTI Router
# =============================================================================

class BreinBETTIRouter:
    """
    Router for BETTI endpoints.
    
    In production, this would be a FastAPI router or similar.
    Here we implement the logic that would be called by HTTP endpoints.
    """
    
    def __init__(self):
        self.service: BETTIService = None
        self.notification_service = None  # WebSocket/Push notification service
    
    async def initialize(self, jis_integration=None):
        """Initialize the router"""
        self.service = BETTIService()
        await self.service.initialize(jis_integration)
        
        # Set up notification forwarding
        self.service.set_notification_callback(self._forward_notification)
    
    async def _forward_notification(self, notification: Dict):
        """Forward notification to recipient"""
        if self.notification_service:
            await self.notification_service.send(notification)
        else:
            print(f"[BREIN-BETTI] Notification: {notification}")
    
    # -------------------------------------------------------------------------
    # Endpoints
    # -------------------------------------------------------------------------
    
    async def create_tbet(self, request: TBETCreateRequest) -> Dict:
        """
        POST /betti/tbet
        Create and submit a new TBET
        """
        try:
            # Parse classification and type
            classification = IntentClassification(request.classification)
            tbet_type = TBETType(request.tbet_type)
            proposed_time = datetime.fromisoformat(request.proposed_start)
            
            # Create TBET
            tbet = await self.service.request_registered_contact(
                initiator_did=request.initiator_did,
                recipient_did=request.recipient_did,
                contact_type=tbet_type,
                subject=request.subject,
                description=request.description,
                proposed_time=proposed_time,
                duration_minutes=request.duration_minutes,
                classification=classification
            )
            
            return {
                "success": True,
                "tbet_id": tbet.tbet_id,
                "status": tbet.status.value,
                "pre_commit_hash": tbet.pre_commit_hash,
                "proposed_slot": {
                    "start": tbet.proposed_slot.start.isoformat(),
                    "end": tbet.proposed_slot.end.isoformat()
                }
            }
            
        except ValueError as e:
            return {"success": False, "error": str(e)}
    
    async def respond_to_tbet(self, request: TBETResponseRequest) -> Dict:
        """
        POST /betti/tbet/{tbet_id}/respond
        Respond to a TBET (accept/reject/counter)
        """
        try:
            if request.action == "accept":
                tbet = await self.service.respond_to_tbet(
                    request.tbet_id,
                    request.responder_did,
                    accept=True
                )
            elif request.action == "reject":
                tbet = await self.service.respond_to_tbet(
                    request.tbet_id,
                    request.responder_did,
                    accept=False,
                    reason=request.reason
                )
            elif request.action == "counter":
                counter_time = datetime.fromisoformat(request.counter_time)
                tbet = await self.service.respond_to_tbet(
                    request.tbet_id,
                    request.responder_did,
                    accept=False,
                    counter_time=counter_time
                )
            else:
                return {"success": False, "error": f"Unknown action: {request.action}"}
            
            return {
                "success": True,
                "tbet_id": tbet.tbet_id,
                "status": tbet.status.value,
                "confirmed_slot": {
                    "start": tbet.confirmed_slot.start.isoformat(),
                    "end": tbet.confirmed_slot.end.isoformat()
                } if tbet.confirmed_slot else None
            }
            
        except ValueError as e:
            return {"success": False, "error": str(e)}
    
    async def execute_tbet(self, request: TBETExecutionRequest) -> Dict:
        """
        POST /betti/tbet/{tbet_id}/execute
        Start or complete TBET execution
        """
        try:
            if request.action == "start":
                tbet = await self.service.start_registered_communication(
                    request.tbet_id
                )
                return {
                    "success": True,
                    "tbet_id": tbet.tbet_id,
                    "status": tbet.status.value,
                    "started_at": tbet.proof.started_at
                }
            
            elif request.action == "complete":
                tbet = await self.service.end_registered_communication(
                    request.tbet_id,
                    outcome=request.outcome or "completed",
                    notes=request.notes
                )
                return {
                    "success": True,
                    "tbet_id": tbet.tbet_id,
                    "status": tbet.status.value,
                    "proof": {
                        "started_at": tbet.proof.started_at,
                        "ended_at": tbet.proof.ended_at,
                        "duration_seconds": tbet.proof.duration_seconds,
                        "execution_hash": tbet.proof.execution_hash,
                        "outcome": tbet.proof.outcome
                    },
                    "post_commit_hash": tbet.post_commit_hash
                }
            
            elif request.action == "fail":
                # Mark as failed
                tbet = self.service.registry.get_tbet(request.tbet_id)
                if tbet:
                    await self.service.registry._transition_status(
                        tbet, TBETStatus.FAILED
                    )
                    tbet.metadata["failure_reason"] = request.notes
                return {
                    "success": True,
                    "tbet_id": request.tbet_id,
                    "status": "failed"
                }
            
            else:
                return {"success": False, "error": f"Unknown action: {request.action}"}
            
        except ValueError as e:
            return {"success": False, "error": str(e)}
    
    async def get_tbet(self, tbet_id: str) -> Dict:
        """
        GET /betti/tbet/{tbet_id}
        Get a specific TBET
        """
        tbet = self.service.registry.get_tbet(tbet_id)
        
        if not tbet:
            return {"success": False, "error": "TBET not found"}
        
        return {
            "success": True,
            "tbet": tbet.to_dict()
        }
    
    async def query_tbets(self, request: TBETQueryRequest) -> Dict:
        """
        GET /betti/tbets
        Query TBETs for a DID
        """
        status = TBETStatus(request.status) if request.status else None
        
        tbets = self.service.registry.get_tbets_for_did(
            did=request.did,
            role=request.role,
            status=status
        )
        
        # Apply date filters if provided
        if request.from_date:
            from_dt = datetime.fromisoformat(request.from_date)
            tbets = [t for t in tbets if datetime.fromisoformat(t.created_at) >= from_dt]
        
        if request.to_date:
            to_dt = datetime.fromisoformat(request.to_date)
            tbets = [t for t in tbets if datetime.fromisoformat(t.created_at) <= to_dt]
        
        # Apply limit
        tbets = tbets[:request.limit]
        
        return {
            "success": True,
            "count": len(tbets),
            "tbets": [t.to_dict() for t in tbets]
        }
    
    async def get_pending(self, did: str) -> Dict:
        """
        GET /betti/pending/{did}
        Get pending TBETs for a DID (inbox)
        """
        tbets = self.service.registry.get_pending_for_did(did)
        
        return {
            "success": True,
            "count": len(tbets),
            "pending": [
                {
                    "tbet_id": t.tbet_id,
                    "from": t.initiator.did,
                    "subject": t.intent.subject,
                    "classification": t.intent.classification.value,
                    "type": t.intent.tbet_type.value,
                    "proposed_time": t.proposed_slot.start.isoformat(),
                    "created_at": t.created_at
                }
                for t in tbets
            ]
        }
    
    async def get_upcoming(self, did: str) -> Dict:
        """
        GET /betti/upcoming/{did}
        Get upcoming accepted TBETs (calendar)
        """
        tbets = self.service.registry.get_upcoming_accepted(did)
        
        return {
            "success": True,
            "count": len(tbets),
            "upcoming": [
                {
                    "tbet_id": t.tbet_id,
                    "other_party": t.recipient.did if t.initiator.did == did else t.initiator.did,
                    "subject": t.intent.subject,
                    "classification": t.intent.classification.value,
                    "type": t.intent.tbet_type.value,
                    "confirmed_time": t.confirmed_slot.start.isoformat(),
                    "duration_minutes": t.confirmed_slot.duration_minutes()
                }
                for t in tbets
            ]
        }
    
    async def check_availability(
        self,
        did: str,
        start: str,
        duration_minutes: int = 30
    ) -> Dict:
        """
        GET /betti/availability/{did}
        Check if a time slot is available
        """
        start_dt = datetime.fromisoformat(start)
        slot = TimeSlot(
            start=start_dt,
            end=start_dt + timedelta(minutes=duration_minutes)
        )
        
        conflicts = await self.service.registry.check_conflicts(did, slot)
        
        return {
            "success": True,
            "available": len(conflicts) == 0,
            "conflicts": [
                {
                    "tbet_id": c.tbet_id,
                    "subject": c.intent.subject,
                    "time": (c.confirmed_slot or c.proposed_slot).start.isoformat()
                }
                for c in conflicts
            ]
        }
    
    async def cancel_tbet(self, tbet_id: str, canceller_did: str, reason: str = None) -> Dict:
        """
        DELETE /betti/tbet/{tbet_id}
        Cancel a TBET
        """
        try:
            tbet = await self.service.registry.cancel_tbet(
                tbet_id,
                canceller_did,
                reason
            )
            
            return {
                "success": True,
                "tbet_id": tbet.tbet_id,
                "status": tbet.status.value
            }
            
        except ValueError as e:
            return {"success": False, "error": str(e)}


# =============================================================================
# WebSocket Handler for Real-time TBET Updates
# =============================================================================

class BETTIWebSocketHandler:
    """
    Handles WebSocket connections for real-time TBET updates.
    
    Messages:
    - tbet_request: New TBET request received
    - tbet_accepted: TBET was accepted
    - tbet_rejected: TBET was rejected
    - tbet_countered: Counter-proposal received
    - tbet_reminder: Upcoming TBET reminder
    - tbet_starting: TBET execution starting
    - tbet_completed: TBET completed
    """
    
    def __init__(self, router: BreinBETTIRouter):
        self.router = router
        self.connections: Dict[str, Any] = {}  # DID -> WebSocket
    
    def register_connection(self, did: str, websocket):
        """Register a WebSocket connection for a DID"""
        self.connections[did] = websocket
    
    def unregister_connection(self, did: str):
        """Unregister a WebSocket connection"""
        self.connections.pop(did, None)
    
    async def send_to_did(self, did: str, message: Dict):
        """Send a message to a specific DID"""
        ws = self.connections.get(did)
        if ws:
            try:
                await ws.send_json(message)
            except Exception as e:
                print(f"[BETTI-WS] Send error: {e}")
                self.unregister_connection(did)
    
    async def handle_message(self, did: str, message: Dict):
        """Handle incoming WebSocket message"""
        msg_type = message.get("type")
        
        if msg_type == "create_tbet":
            request = TBETCreateRequest(**message.get("data", {}))
            result = await self.router.create_tbet(request)
            await self.send_to_did(did, {"type": "tbet_created", "data": result})
        
        elif msg_type == "respond_tbet":
            request = TBETResponseRequest(**message.get("data", {}))
            result = await self.router.respond_to_tbet(request)
            await self.send_to_did(did, {"type": "tbet_response", "data": result})
        
        elif msg_type == "get_pending":
            result = await self.router.get_pending(did)
            await self.send_to_did(did, {"type": "pending_tbets", "data": result})
        
        elif msg_type == "get_upcoming":
            result = await self.router.get_upcoming(did)
            await self.send_to_did(did, {"type": "upcoming_tbets", "data": result})


# =============================================================================
# FastAPI Integration Example
# =============================================================================

"""
# In your FastAPI app:

from fastapi import FastAPI, WebSocket, HTTPException
from brein_betti_endpoints import BreinBETTIRouter, TBETCreateRequest

app = FastAPI()
betti_router = BreinBETTIRouter()

@app.on_event("startup")
async def startup():
    await betti_router.initialize()

@app.post("/betti/tbet")
async def create_tbet(request: TBETCreateRequest):
    result = await betti_router.create_tbet(request)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
    return result

@app.post("/betti/tbet/{tbet_id}/respond")
async def respond_tbet(tbet_id: str, request: TBETResponseRequest):
    request.tbet_id = tbet_id
    result = await betti_router.respond_to_tbet(request)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
    return result

@app.get("/betti/tbet/{tbet_id}")
async def get_tbet(tbet_id: str):
    result = await betti_router.get_tbet(tbet_id)
    if not result["success"]:
        raise HTTPException(status_code=404, detail=result["error"])
    return result

@app.get("/betti/pending/{did}")
async def get_pending(did: str):
    return await betti_router.get_pending(did)

@app.get("/betti/upcoming/{did}")
async def get_upcoming(did: str):
    return await betti_router.get_upcoming(did)

@app.websocket("/betti/ws/{did}")
async def betti_websocket(websocket: WebSocket, did: str):
    await websocket.accept()
    handler = BETTIWebSocketHandler(betti_router)
    handler.register_connection(did, websocket)
    
    try:
        while True:
            data = await websocket.receive_json()
            await handler.handle_message(did, data)
    except:
        handler.unregister_connection(did)
"""


# =============================================================================
# CLI Test
# =============================================================================

async def main():
    """Test the Brein BETTI endpoints"""
    
    router = BreinBETTIRouter()
    await router.initialize()
    
    print("=" * 60)
    print("Testing Brein BETTI Endpoints")
    print("=" * 60)
    
    # Create TBET
    print("\n1. Creating TBET...")
    create_request = TBETCreateRequest(
        initiator_did="did:jtel:user:jasper",
        recipient_did="did:jtel:org:notaris-utrecht",
        tbet_type="document",
        classification="legal",
        subject="Aangetekend: Koopakte woning",
        description="Ondertekening koopakte voor woning aan de Maliebaan 123",
        proposed_start=(datetime.now() + timedelta(days=1)).isoformat(),
        duration_minutes=60
    )
    
    result = await router.create_tbet(create_request)
    print(f"Result: {json.dumps(result, indent=2)}")
    
    tbet_id = result["tbet_id"]
    
    # Get pending for recipient
    print("\n2. Checking pending for recipient...")
    pending = await router.get_pending("did:jtel:org:notaris-utrecht")
    print(f"Pending: {json.dumps(pending, indent=2)}")
    
    # Accept TBET
    print("\n3. Accepting TBET...")
    respond_request = TBETResponseRequest(
        tbet_id=tbet_id,
        responder_did="did:jtel:org:notaris-utrecht",
        action="accept"
    )
    
    result = await router.respond_to_tbet(respond_request)
    print(f"Result: {json.dumps(result, indent=2)}")
    
    # Get upcoming
    print("\n4. Checking upcoming for initiator...")
    upcoming = await router.get_upcoming("did:jtel:user:jasper")
    print(f"Upcoming: {json.dumps(upcoming, indent=2)}")
    
    # Start execution
    print("\n5. Starting execution...")
    exec_request = TBETExecutionRequest(
        tbet_id=tbet_id,
        action="start"
    )
    
    result = await router.execute_tbet(exec_request)
    print(f"Result: {json.dumps(result, indent=2)}")
    
    # Complete execution
    print("\n6. Completing execution...")
    exec_request = TBETExecutionRequest(
        tbet_id=tbet_id,
        action="complete",
        outcome="signed",
        notes="Koopakte ondertekend door beide partijen"
    )
    
    result = await router.execute_tbet(exec_request)
    print(f"Result: {json.dumps(result, indent=2)}")
    
    # Get final TBET
    print("\n7. Final TBET state...")
    result = await router.get_tbet(tbet_id)
    print(f"Full TBET: {json.dumps(result, indent=2, default=str)}")
    
    print("\n" + "=" * 60)
    print("Test complete!")
    print("=" * 60)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
