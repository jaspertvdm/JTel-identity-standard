"""
BETTI - Base Event Token Time Intent
=====================================

The missing link for registered/certified communication.

BETTI manages Time Based Event Tokens (TBETs) which enable:
- Pre-announced intent before communication
- Mutual commitment to a time slot
- Irrefutable proof of intent BEFORE contact
- Registered mail/call/message functionality
- Legal-grade communication trails

Flow:
1. Initiator creates TBET with intent + proposed time
2. BETTI validates and stores pending TBET
3. Recipient receives notification
4. Recipient accepts/rejects/proposes alternative
5. On accept: both parties committed, chain starts
6. Communication happens within time slot
7. TBET marked as executed with proof

Author: Jasper van de Meent / JTel
"""

import asyncio
import json
import hashlib
import uuid
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict, field
from typing import Optional, Dict, List, Any, Callable
from enum import Enum
from pathlib import Path
import aiofiles


# =============================================================================
# Enums and Constants
# =============================================================================

class IntentClassification(Enum):
    """Classification of communication intent - determines TBET requirements"""
    
    CASUAL = "casual"           # No TBET needed, regular contact
    BUSINESS = "business"       # TBET optional, recommended for records
    FORMAL = "formal"           # TBET required, both parties must accept
    LEGAL = "legal"             # TBET required + third party attestation
    GOVERNMENT = "government"   # TBET required + official verification
    EMERGENCY = "emergency"     # Can bypass TBET, but logged retroactively


class TBETStatus(Enum):
    """Status of a Time Based Event Token"""
    
    DRAFT = "draft"             # Created but not sent
    PENDING = "pending"         # Sent, awaiting response
    ACCEPTED = "accepted"       # Both parties committed
    REJECTED = "rejected"       # Recipient declined
    COUNTERED = "countered"     # Recipient proposed alternative
    EXPIRED = "expired"         # Time slot passed without resolution
    CANCELLED = "cancelled"     # Initiator cancelled
    EXECUTING = "executing"     # Communication in progress
    COMPLETED = "completed"     # Successfully executed
    FAILED = "failed"           # Execution failed (no-show, tech issue)
    DISPUTED = "disputed"       # One party disputes the outcome


class TBETType(Enum):
    """Type of communication the TBET covers"""
    
    CALL = "call"               # Voice/video call
    MESSAGE = "message"         # Registered message
    DOCUMENT = "document"       # Document delivery
    MEETING = "meeting"         # Scheduled meeting
    SIGNATURE = "signature"     # Document signing
    VERIFICATION = "verification"  # Identity verification
    TRANSACTION = "transaction" # Financial/legal transaction


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class TimeSlot:
    """A proposed or confirmed time slot"""
    start: datetime
    end: datetime
    timezone: str = "Europe/Amsterdam"
    flexible: bool = False      # Can be adjusted?
    buffer_minutes: int = 5     # Buffer before/after
    
    def overlaps(self, other: 'TimeSlot') -> bool:
        """Check if this slot overlaps with another"""
        return self.start < other.end and other.start < self.end
    
    def is_valid(self) -> bool:
        """Check if slot is valid (end after start, not in past)"""
        return self.end > self.start and self.start > datetime.now()
    
    def duration_minutes(self) -> int:
        """Get duration in minutes"""
        return int((self.end - self.start).total_seconds() / 60)


@dataclass
class TBETParty:
    """A party involved in a TBET"""
    did: str
    role: str                   # "initiator" or "recipient"
    accepted: bool = False
    accepted_at: Optional[str] = None
    signature: Optional[str] = None
    attestation: Optional[str] = None  # Third party attestation


@dataclass
class TBETIntent:
    """The declared intent of the communication"""
    classification: IntentClassification
    tbet_type: TBETType
    subject: str                # Brief subject line
    description: str            # Detailed description
    attachments: List[str] = field(default_factory=list)  # Document hashes
    requires_response: bool = True
    response_deadline: Optional[str] = None
    legal_basis: Optional[str] = None  # For legal/government
    reference_number: Optional[str] = None  # External reference


@dataclass 
class TBETProof:
    """Proof of TBET execution"""
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    duration_seconds: Optional[int] = None
    execution_hash: Optional[str] = None  # Hash of the communication
    recording_hash: Optional[str] = None  # If recorded
    transcript_hash: Optional[str] = None  # If transcribed
    witnesses: List[str] = field(default_factory=list)  # Witness DIDs
    outcome: Optional[str] = None
    notes: Optional[str] = None


@dataclass
class TBET:
    """Time Based Event Token - the core unit"""
    
    # Identity
    tbet_id: str
    created_at: str
    updated_at: str
    
    # Parties
    initiator: TBETParty
    recipient: TBETParty
    witnesses: List[TBETParty] = field(default_factory=list)
    
    # Intent
    intent: TBETIntent = None
    
    # Time
    proposed_slot: TimeSlot = None
    confirmed_slot: Optional[TimeSlot] = None
    counter_slots: List[TimeSlot] = field(default_factory=list)
    
    # Status
    status: TBETStatus = TBETStatus.DRAFT
    status_history: List[Dict] = field(default_factory=list)
    
    # Chain integration
    pre_commit_hash: Optional[str] = None   # Hash before communication
    post_commit_hash: Optional[str] = None  # Hash after communication
    chain_events: List[str] = field(default_factory=list)  # Event IDs
    
    # Proof
    proof: Optional[TBETProof] = None
    
    # Metadata
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for storage"""
        data = asdict(self)
        # Convert enums
        data['intent']['classification'] = self.intent.classification.value
        data['intent']['tbet_type'] = self.intent.tbet_type.value
        data['status'] = self.status.value
        # Convert datetimes in slots
        if self.proposed_slot:
            data['proposed_slot']['start'] = self.proposed_slot.start.isoformat()
            data['proposed_slot']['end'] = self.proposed_slot.end.isoformat()
        if self.confirmed_slot:
            data['confirmed_slot']['start'] = self.confirmed_slot.start.isoformat()
            data['confirmed_slot']['end'] = self.confirmed_slot.end.isoformat()
        return data
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TBET':
        """Create from dictionary"""
        # Convert enums back
        if data.get('intent'):
            data['intent']['classification'] = IntentClassification(data['intent']['classification'])
            data['intent']['tbet_type'] = TBETType(data['intent']['tbet_type'])
            data['intent'] = TBETIntent(**data['intent'])
        data['status'] = TBETStatus(data['status'])
        # Convert parties
        data['initiator'] = TBETParty(**data['initiator'])
        data['recipient'] = TBETParty(**data['recipient'])
        data['witnesses'] = [TBETParty(**w) for w in data.get('witnesses', [])]
        # Convert slots
        if data.get('proposed_slot'):
            slot = data['proposed_slot']
            slot['start'] = datetime.fromisoformat(slot['start'])
            slot['end'] = datetime.fromisoformat(slot['end'])
            data['proposed_slot'] = TimeSlot(**slot)
        if data.get('confirmed_slot'):
            slot = data['confirmed_slot']
            slot['start'] = datetime.fromisoformat(slot['start'])
            slot['end'] = datetime.fromisoformat(slot['end'])
            data['confirmed_slot'] = TimeSlot(**slot)
        if data.get('proof'):
            data['proof'] = TBETProof(**data['proof'])
        return cls(**data)


# =============================================================================
# TBET Builder
# =============================================================================

class TBETBuilder:
    """Fluent builder for creating TBETs"""
    
    def __init__(self, initiator_did: str):
        self.tbet_id = str(uuid.uuid4())
        self.initiator_did = initiator_did
        self.recipient_did = None
        self.intent = None
        self.proposed_slot = None
        self.witnesses = []
        self.metadata = {}
    
    def to(self, recipient_did: str) -> 'TBETBuilder':
        """Set recipient"""
        self.recipient_did = recipient_did
        return self
    
    def with_intent(
        self,
        classification: IntentClassification,
        tbet_type: TBETType,
        subject: str,
        description: str = "",
        **kwargs
    ) -> 'TBETBuilder':
        """Set intent"""
        self.intent = TBETIntent(
            classification=classification,
            tbet_type=tbet_type,
            subject=subject,
            description=description,
            **kwargs
        )
        return self
    
    def at_time(
        self,
        start: datetime,
        duration_minutes: int = 30,
        flexible: bool = False
    ) -> 'TBETBuilder':
        """Set proposed time slot"""
        self.proposed_slot = TimeSlot(
            start=start,
            end=start + timedelta(minutes=duration_minutes),
            flexible=flexible
        )
        return self
    
    def with_witness(self, witness_did: str) -> 'TBETBuilder':
        """Add a witness"""
        self.witnesses.append(witness_did)
        return self
    
    def with_metadata(self, key: str, value: Any) -> 'TBETBuilder':
        """Add metadata"""
        self.metadata[key] = value
        return self
    
    def build(self) -> TBET:
        """Build the TBET"""
        if not self.recipient_did:
            raise ValueError("Recipient DID required")
        if not self.intent:
            raise ValueError("Intent required")
        if not self.proposed_slot:
            raise ValueError("Proposed time slot required")
        
        now = datetime.utcnow().isoformat()
        
        return TBET(
            tbet_id=self.tbet_id,
            created_at=now,
            updated_at=now,
            initiator=TBETParty(
                did=self.initiator_did,
                role="initiator",
                accepted=True,  # Initiator implicitly accepts
                accepted_at=now
            ),
            recipient=TBETParty(
                did=self.recipient_did,
                role="recipient"
            ),
            witnesses=[
                TBETParty(did=w, role="witness")
                for w in self.witnesses
            ],
            intent=self.intent,
            proposed_slot=self.proposed_slot,
            status=TBETStatus.DRAFT,
            metadata=self.metadata
        )


# =============================================================================
# BETTI Registry
# =============================================================================

class BETTIRegistry:
    """
    Base Event Token Time Intent Registry
    
    Central registry for all TBETs. Handles:
    - TBET storage and retrieval
    - Status transitions
    - Time slot management
    - Chain integration
    - Notifications
    """
    
    def __init__(self, storage_path: Path = None):
        self.storage_path = storage_path or Path("/home/pi/.jtel/betti")
        self.tbets: Dict[str, TBET] = {}
        self.by_initiator: Dict[str, List[str]] = {}  # DID -> TBET IDs
        self.by_recipient: Dict[str, List[str]] = {}  # DID -> TBET IDs
        self.pending_slots: Dict[str, List[str]] = {} # Time bucket -> TBET IDs
        
        self.event_handlers: Dict[str, List[Callable]] = {}
        
    async def initialize(self):
        """Initialize the registry"""
        self.storage_path.mkdir(parents=True, exist_ok=True)
        await self._load_tbets()
        print(f"[BETTI] Initialized with {len(self.tbets)} TBETs")
    
    async def _load_tbets(self):
        """Load TBETs from storage"""
        tbet_file = self.storage_path / "tbets.json"
        if tbet_file.exists():
            async with aiofiles.open(tbet_file, 'r') as f:
                data = json.loads(await f.read())
                for tbet_data in data.get("tbets", []):
                    tbet = TBET.from_dict(tbet_data)
                    self._index_tbet(tbet)
    
    async def _save_tbets(self):
        """Save TBETs to storage"""
        data = {
            "tbets": [t.to_dict() for t in self.tbets.values()],
            "updated_at": datetime.utcnow().isoformat()
        }
        async with aiofiles.open(self.storage_path / "tbets.json", 'w') as f:
            await f.write(json.dumps(data, indent=2, default=str))
    
    def _index_tbet(self, tbet: TBET):
        """Index a TBET for quick lookup"""
        self.tbets[tbet.tbet_id] = tbet
        
        # By initiator
        if tbet.initiator.did not in self.by_initiator:
            self.by_initiator[tbet.initiator.did] = []
        if tbet.tbet_id not in self.by_initiator[tbet.initiator.did]:
            self.by_initiator[tbet.initiator.did].append(tbet.tbet_id)
        
        # By recipient
        if tbet.recipient.did not in self.by_recipient:
            self.by_recipient[tbet.recipient.did] = []
        if tbet.tbet_id not in self.by_recipient[tbet.recipient.did]:
            self.by_recipient[tbet.recipient.did].append(tbet.tbet_id)
    
    # -------------------------------------------------------------------------
    # TBET Lifecycle
    # -------------------------------------------------------------------------
    
    async def create_tbet(self, tbet: TBET) -> TBET:
        """Register a new TBET"""
        
        # Validate
        if not tbet.proposed_slot.is_valid():
            raise ValueError("Invalid time slot")
        
        # Check for conflicts
        conflicts = await self.check_conflicts(
            tbet.recipient.did,
            tbet.proposed_slot
        )
        if conflicts:
            tbet.metadata["conflicts"] = [c.tbet_id for c in conflicts]
        
        # Generate pre-commit hash
        tbet.pre_commit_hash = self._generate_hash(tbet)
        
        # Index
        self._index_tbet(tbet)
        
        # Save
        await self._save_tbets()
        
        print(f"[BETTI] Created TBET: {tbet.tbet_id}")
        return tbet
    
    async def submit_tbet(self, tbet_id: str) -> TBET:
        """Submit a TBET (send to recipient)"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        if tbet.status != TBETStatus.DRAFT:
            raise ValueError(f"TBET not in draft status: {tbet.status}")
        
        # Transition to pending
        await self._transition_status(tbet, TBETStatus.PENDING)
        
        # Emit event for notification
        await self._emit_event("tbet_submitted", tbet)
        
        return tbet
    
    async def accept_tbet(
        self,
        tbet_id: str,
        acceptor_did: str,
        signature: str = None
    ) -> TBET:
        """Accept a TBET"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        if tbet.status != TBETStatus.PENDING:
            raise ValueError(f"TBET not pending: {tbet.status}")
        
        if tbet.recipient.did != acceptor_did:
            raise ValueError("Only recipient can accept")
        
        # Update recipient
        tbet.recipient.accepted = True
        tbet.recipient.accepted_at = datetime.utcnow().isoformat()
        tbet.recipient.signature = signature
        
        # Confirm slot
        tbet.confirmed_slot = tbet.proposed_slot
        
        # Transition
        await self._transition_status(tbet, TBETStatus.ACCEPTED)
        
        # Emit event
        await self._emit_event("tbet_accepted", tbet)
        
        print(f"[BETTI] TBET accepted: {tbet_id}")
        return tbet
    
    async def reject_tbet(
        self,
        tbet_id: str,
        rejector_did: str,
        reason: str = None
    ) -> TBET:
        """Reject a TBET"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        if tbet.recipient.did != rejector_did:
            raise ValueError("Only recipient can reject")
        
        tbet.metadata["rejection_reason"] = reason
        
        await self._transition_status(tbet, TBETStatus.REJECTED)
        await self._emit_event("tbet_rejected", tbet)
        
        print(f"[BETTI] TBET rejected: {tbet_id}")
        return tbet
    
    async def counter_tbet(
        self,
        tbet_id: str,
        counter_did: str,
        new_slot: TimeSlot
    ) -> TBET:
        """Counter-propose a different time"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        if not new_slot.is_valid():
            raise ValueError("Invalid counter slot")
        
        tbet.counter_slots.append(new_slot)
        tbet.metadata["counter_by"] = counter_did
        
        await self._transition_status(tbet, TBETStatus.COUNTERED)
        await self._emit_event("tbet_countered", tbet)
        
        return tbet
    
    async def start_execution(self, tbet_id: str) -> TBET:
        """Mark TBET as executing (communication started)"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        if tbet.status != TBETStatus.ACCEPTED:
            raise ValueError("TBET must be accepted to execute")
        
        # Initialize proof
        tbet.proof = TBETProof(
            started_at=datetime.utcnow().isoformat()
        )
        
        await self._transition_status(tbet, TBETStatus.EXECUTING)
        await self._emit_event("tbet_executing", tbet)
        
        return tbet
    
    async def complete_execution(
        self,
        tbet_id: str,
        outcome: str = "completed",
        execution_hash: str = None,
        notes: str = None
    ) -> TBET:
        """Mark TBET as completed"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        if tbet.status != TBETStatus.EXECUTING:
            raise ValueError("TBET must be executing to complete")
        
        # Finalize proof
        now = datetime.utcnow()
        tbet.proof.ended_at = now.isoformat()
        tbet.proof.outcome = outcome
        tbet.proof.notes = notes
        tbet.proof.execution_hash = execution_hash or self._generate_hash(tbet)
        
        if tbet.proof.started_at:
            start = datetime.fromisoformat(tbet.proof.started_at)
            tbet.proof.duration_seconds = int((now - start).total_seconds())
        
        # Generate post-commit hash
        tbet.post_commit_hash = self._generate_hash(tbet)
        
        await self._transition_status(tbet, TBETStatus.COMPLETED)
        await self._emit_event("tbet_completed", tbet)
        
        print(f"[BETTI] TBET completed: {tbet_id}")
        return tbet
    
    async def cancel_tbet(
        self,
        tbet_id: str,
        canceller_did: str,
        reason: str = None
    ) -> TBET:
        """Cancel a TBET"""
        tbet = self.tbets.get(tbet_id)
        if not tbet:
            raise ValueError(f"TBET not found: {tbet_id}")
        
        # Only initiator can cancel, and only before execution
        if tbet.initiator.did != canceller_did:
            raise ValueError("Only initiator can cancel")
        
        if tbet.status in [TBETStatus.EXECUTING, TBETStatus.COMPLETED]:
            raise ValueError("Cannot cancel during/after execution")
        
        tbet.metadata["cancellation_reason"] = reason
        
        await self._transition_status(tbet, TBETStatus.CANCELLED)
        await self._emit_event("tbet_cancelled", tbet)
        
        return tbet
    
    # -------------------------------------------------------------------------
    # Queries
    # -------------------------------------------------------------------------
    
    def get_tbet(self, tbet_id: str) -> Optional[TBET]:
        """Get a TBET by ID"""
        return self.tbets.get(tbet_id)
    
    def get_tbets_for_did(
        self,
        did: str,
        role: str = None,
        status: TBETStatus = None
    ) -> List[TBET]:
        """Get TBETs for a DID"""
        tbet_ids = set()
        
        if role in [None, "initiator"]:
            tbet_ids.update(self.by_initiator.get(did, []))
        if role in [None, "recipient"]:
            tbet_ids.update(self.by_recipient.get(did, []))
        
        tbets = [self.tbets[tid] for tid in tbet_ids if tid in self.tbets]
        
        if status:
            tbets = [t for t in tbets if t.status == status]
        
        return sorted(tbets, key=lambda t: t.created_at, reverse=True)
    
    def get_pending_for_did(self, did: str) -> List[TBET]:
        """Get pending TBETs where DID is recipient"""
        return [
            self.tbets[tid]
            for tid in self.by_recipient.get(did, [])
            if tid in self.tbets and self.tbets[tid].status == TBETStatus.PENDING
        ]
    
    def get_upcoming_accepted(self, did: str) -> List[TBET]:
        """Get accepted TBETs with upcoming time slots"""
        now = datetime.now()
        tbets = self.get_tbets_for_did(did, status=TBETStatus.ACCEPTED)
        return [
            t for t in tbets
            if t.confirmed_slot and t.confirmed_slot.start > now
        ]
    
    async def check_conflicts(
        self,
        did: str,
        slot: TimeSlot
    ) -> List[TBET]:
        """Check for conflicting TBETs"""
        conflicts = []
        
        for tbet in self.get_tbets_for_did(did):
            if tbet.status not in [TBETStatus.ACCEPTED, TBETStatus.PENDING]:
                continue
            
            check_slot = tbet.confirmed_slot or tbet.proposed_slot
            if check_slot and check_slot.overlaps(slot):
                conflicts.append(tbet)
        
        return conflicts
    
    # -------------------------------------------------------------------------
    # Internal Helpers
    # -------------------------------------------------------------------------
    
    async def _transition_status(self, tbet: TBET, new_status: TBETStatus):
        """Transition TBET status"""
        old_status = tbet.status
        
        tbet.status_history.append({
            "from": old_status.value,
            "to": new_status.value,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        tbet.status = new_status
        tbet.updated_at = datetime.utcnow().isoformat()
        
        await self._save_tbets()
    
    def _generate_hash(self, tbet: TBET) -> str:
        """Generate a hash for the TBET"""
        data = json.dumps({
            "tbet_id": tbet.tbet_id,
            "initiator": tbet.initiator.did,
            "recipient": tbet.recipient.did,
            "intent": {
                "classification": tbet.intent.classification.value,
                "type": tbet.intent.tbet_type.value,
                "subject": tbet.intent.subject
            },
            "status": tbet.status.value,
            "timestamp": datetime.utcnow().isoformat()
        }, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()
    
    # -------------------------------------------------------------------------
    # Event System
    # -------------------------------------------------------------------------
    
    def on(self, event: str, handler: Callable):
        """Register an event handler"""
        if event not in self.event_handlers:
            self.event_handlers[event] = []
        self.event_handlers[event].append(handler)
    
    async def _emit_event(self, event: str, tbet: TBET):
        """Emit an event"""
        handlers = self.event_handlers.get(event, [])
        for handler in handlers:
            try:
                await handler(tbet)
            except Exception as e:
                print(f"[BETTI] Event handler error: {e}")


# =============================================================================
# BETTI Service (for integration with Brein/Kit)
# =============================================================================

class BETTIService:
    """
    High-level service for BETTI operations.
    Integrates with JIS for chain events and notifications.
    """
    
    def __init__(self, registry: BETTIRegistry = None):
        self.registry = registry or BETTIRegistry()
        self.jis_client = None  # Set externally
        self.notification_callback = None
    
    async def initialize(self, jis_client=None):
        """Initialize the service"""
        await self.registry.initialize()
        self.jis_client = jis_client
        
        # Register event handlers
        self.registry.on("tbet_submitted", self._on_tbet_submitted)
        self.registry.on("tbet_accepted", self._on_tbet_accepted)
        self.registry.on("tbet_rejected", self._on_tbet_rejected)
        self.registry.on("tbet_completed", self._on_tbet_completed)
    
    def set_notification_callback(self, callback: Callable):
        """Set callback for notifications"""
        self.notification_callback = callback
    
    # -------------------------------------------------------------------------
    # High-level Operations
    # -------------------------------------------------------------------------
    
    async def request_registered_contact(
        self,
        initiator_did: str,
        recipient_did: str,
        contact_type: TBETType,
        subject: str,
        description: str,
        proposed_time: datetime,
        duration_minutes: int = 30,
        classification: IntentClassification = IntentClassification.FORMAL
    ) -> TBET:
        """
        Request registered contact with another party.
        This is the main entry point for "aangetekend bellen/mailen".
        """
        
        # Build TBET
        tbet = (TBETBuilder(initiator_did)
            .to(recipient_did)
            .with_intent(
                classification=classification,
                tbet_type=contact_type,
                subject=subject,
                description=description
            )
            .at_time(proposed_time, duration_minutes)
            .build())
        
        # Create and submit
        tbet = await self.registry.create_tbet(tbet)
        tbet = await self.registry.submit_tbet(tbet.tbet_id)
        
        # Log to chain if JIS available
        if self.jis_client:
            await self.jis_client.chain.append(
                event_type="tbet_initiated",
                remote_did=recipient_did,
                result="pending",
                extra_data={
                    "tbet_id": tbet.tbet_id,
                    "subject": subject,
                    "classification": classification.value
                }
            )
        
        return tbet
    
    async def respond_to_tbet(
        self,
        tbet_id: str,
        responder_did: str,
        accept: bool,
        counter_time: datetime = None,
        reason: str = None
    ) -> TBET:
        """Respond to a TBET request"""
        
        if accept:
            return await self.registry.accept_tbet(tbet_id, responder_did)
        elif counter_time:
            slot = TimeSlot(
                start=counter_time,
                end=counter_time + timedelta(minutes=30)
            )
            return await self.registry.counter_tbet(tbet_id, responder_did, slot)
        else:
            return await self.registry.reject_tbet(tbet_id, responder_did, reason)
    
    async def start_registered_communication(self, tbet_id: str) -> TBET:
        """Start the registered communication"""
        tbet = await self.registry.start_execution(tbet_id)
        
        if self.jis_client:
            await self.jis_client.chain.append(
                event_type="tbet_started",
                remote_did=tbet.recipient.did,
                result="executing",
                extra_data={"tbet_id": tbet_id}
            )
        
        return tbet
    
    async def end_registered_communication(
        self,
        tbet_id: str,
        outcome: str = "completed",
        notes: str = None
    ) -> TBET:
        """End the registered communication"""
        
        # Generate execution hash from chain
        execution_hash = None
        if self.jis_client:
            execution_hash = self.jis_client.chain.current_hash
        
        tbet = await self.registry.complete_execution(
            tbet_id,
            outcome=outcome,
            execution_hash=execution_hash,
            notes=notes
        )
        
        if self.jis_client:
            await self.jis_client.chain.append(
                event_type="tbet_completed",
                remote_did=tbet.recipient.did,
                result=outcome,
                extra_data={
                    "tbet_id": tbet_id,
                    "duration": tbet.proof.duration_seconds,
                    "post_commit_hash": tbet.post_commit_hash
                }
            )
        
        return tbet
    
    # -------------------------------------------------------------------------
    # Event Handlers
    # -------------------------------------------------------------------------
    
    async def _on_tbet_submitted(self, tbet: TBET):
        """Handle TBET submission"""
        if self.notification_callback:
            await self.notification_callback({
                "type": "tbet_request",
                "tbet_id": tbet.tbet_id,
                "from": tbet.initiator.did,
                "subject": tbet.intent.subject,
                "classification": tbet.intent.classification.value,
                "proposed_time": tbet.proposed_slot.start.isoformat()
            })
    
    async def _on_tbet_accepted(self, tbet: TBET):
        """Handle TBET acceptance"""
        if self.notification_callback:
            await self.notification_callback({
                "type": "tbet_accepted",
                "tbet_id": tbet.tbet_id,
                "confirmed_time": tbet.confirmed_slot.start.isoformat()
            })
    
    async def _on_tbet_rejected(self, tbet: TBET):
        """Handle TBET rejection"""
        if self.notification_callback:
            await self.notification_callback({
                "type": "tbet_rejected",
                "tbet_id": tbet.tbet_id,
                "reason": tbet.metadata.get("rejection_reason")
            })
    
    async def _on_tbet_completed(self, tbet: TBET):
        """Handle TBET completion"""
        print(f"[BETTI] Registered communication completed: {tbet.tbet_id}")
        print(f"[BETTI] Duration: {tbet.proof.duration_seconds}s")
        print(f"[BETTI] Proof hash: {tbet.post_commit_hash}")


# =============================================================================
# CLI for Testing
# =============================================================================

async def main():
    """Test BETTI"""
    
    # Initialize
    service = BETTIService()
    await service.initialize()
    
    # Set notification callback
    async def notify(msg):
        print(f"[NOTIFY] {json.dumps(msg, indent=2)}")
    
    service.set_notification_callback(notify)
    
    # Create a registered call request
    print("\n" + "=" * 50)
    print("Creating registered call request...")
    print("=" * 50)
    
    tbet = await service.request_registered_contact(
        initiator_did="did:jtel:user:jasper",
        recipient_did="did:jtel:org:gemeente-zeist",
        contact_type=TBETType.CALL,
        subject="Aangetekend: Bezwaar WOZ-beschikking",
        description="Formeel bezwaar tegen WOZ-waarde 2024",
        proposed_time=datetime.now() + timedelta(hours=2),
        duration_minutes=30,
        classification=IntentClassification.LEGAL
    )
    
    print(f"\nTBET created: {tbet.tbet_id}")
    print(f"Status: {tbet.status.value}")
    print(f"Pre-commit hash: {tbet.pre_commit_hash}")
    
    # Simulate acceptance
    print("\n" + "=" * 50)
    print("Recipient accepts...")
    print("=" * 50)
    
    tbet = await service.respond_to_tbet(
        tbet.tbet_id,
        "did:jtel:org:gemeente-zeist",
        accept=True
    )
    
    print(f"Status: {tbet.status.value}")
    print(f"Confirmed slot: {tbet.confirmed_slot.start}")
    
    # Simulate execution
    print("\n" + "=" * 50)
    print("Starting communication...")
    print("=" * 50)
    
    tbet = await service.start_registered_communication(tbet.tbet_id)
    print(f"Status: {tbet.status.value}")
    print(f"Started at: {tbet.proof.started_at}")
    
    # Simulate some time passing
    await asyncio.sleep(2)
    
    # Complete
    print("\n" + "=" * 50)
    print("Completing communication...")
    print("=" * 50)
    
    tbet = await service.end_registered_communication(
        tbet.tbet_id,
        outcome="completed",
        notes="Bezwaar besproken, schriftelijke bevestiging volgt"
    )
    
    print(f"Status: {tbet.status.value}")
    print(f"Duration: {tbet.proof.duration_seconds}s")
    print(f"Post-commit hash: {tbet.post_commit_hash}")
    
    # Show full TBET
    print("\n" + "=" * 50)
    print("Full TBET record:")
    print("=" * 50)
    print(json.dumps(tbet.to_dict(), indent=2, default=str))


if __name__ == "__main__":
    asyncio.run(main())
